/* global React */

// ============================================================
// Shared bits
// ============================================================
const Caret = ({ size = 12 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
);

const SearchIcon = ({ size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
);

const PlusIcon = ({ size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>
);

const PhoneIc = ({ size = 12 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
);

const MailIc = ({ size = 12 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></svg>
);

// ============================================================
// 01 · CLIENTS
// ============================================================
window.ClientsScreen = function ClientsScreen() {
  const [filter, setFilter] = React.useState('all');
  return (
    <div className="screen">
      <div className="app-head app-head--titled">
        <div className="app-head__title-block">
          <div className="eyebrow eyebrow--gold">47 active</div>
          <h1 className="page-h1">Clients</h1>
        </div>
        <div className="app-head__actions">
          <button className="icon-btn" aria-label="Search"><SearchIcon size={15}/></button>
          <button className="icon-btn" aria-label="Add client"><PlusIcon size={15}/></button>
        </div>
      </div>

      <div className="screen__body no-scroll">
        <div className="cl-kpi">
          <div className="cl-kpi__cell">
            <div className="cl-kpi__lbl">Lifetime billed</div>
            <div className="cl-kpi__amt stamp">$1.84M</div>
            <div className="cl-kpi__sub">12 yrs · 47 clients</div>
          </div>
          <div className="cl-kpi__div"></div>
          <div className="cl-kpi__cell">
            <div className="cl-kpi__lbl">Outstanding</div>
            <div className="cl-kpi__amt stamp" style={{ color: '#E08B7A' }}>$24,300</div>
            <div className="cl-kpi__sub">3 invoices · 1 overdue</div>
          </div>
        </div>

        <div className="cl-search">
          <SearchIcon/>
          <input placeholder="Search by name, address, phone…" />
          <kbd>⌘K</kbd>
        </div>

        <div className="cl-filters">
          <button className={`cl-fil ${filter === 'all' ? 'is-on' : ''}`} onClick={() => setFilter('all')}>All <span className="cl-fil__n">47</span></button>
          <button className={`cl-fil cl-fil--gold ${filter === 'top' ? 'is-on' : ''}`} onClick={() => setFilter('top')}>Top <span className="cl-fil__n">8</span></button>
          <button className={`cl-fil ${filter === 'active' ? 'is-on' : ''}`} onClick={() => setFilter('active')}>Active jobs <span className="cl-fil__n">9</span></button>
          <button className={`cl-fil cl-fil--red ${filter === 'owes' ? 'is-on' : ''}`} onClick={() => setFilter('owes')}>Owes <span className="cl-fil__n">3</span></button>
          <button className={`cl-fil ${filter === 'cold' ? 'is-on' : ''}`} onClick={() => setFilter('cold')}>Cold &gt;90d <span className="cl-fil__n">11</span></button>
        </div>

        <div className="cl-section-lbl">
          <span>Top by lifetime · 30d</span>
          <span className="cl-section-lbl__hint">tap to see jobs</span>
        </div>

        <div className="cl-card cl-card--top">
          <div className="cl-card__rib">TOP CLIENT</div>
          <div className="cl-card__hdr">
            <div className="cl-avatar cl-avatar--gold">MM</div>
            <div className="cl-card__main">
              <div className="cl-card__name">MMC Properties</div>
              <div className="cl-card__kind">Commercial · Tom Mendelson</div>
            </div>
            <div className="cl-card__amt">
              <div className="cl-card__amt-val stamp">$312K</div>
              <div className="cl-card__amt-lbl">LIFETIME</div>
            </div>
          </div>
          <div className="cl-card__strip">
            <div className="cl-strip-cell">
              <div className="cl-strip-cell__lbl">ACTIVE</div>
              <div className="cl-strip-cell__val cl-strip-cell__val--gold">2 jobs</div>
            </div>
            <div className="cl-strip-cell">
              <div className="cl-strip-cell__lbl">OWES</div>
              <div className="cl-strip-cell__val">—</div>
            </div>
            <div className="cl-strip-cell">
              <div className="cl-strip-cell__lbl">LAST</div>
              <div className="cl-strip-cell__val">3d ago</div>
            </div>
          </div>
        </div>

        <div className="cl-section-lbl"><span>Active jobs</span></div>

        <button className="cl-row">
          <div className="cl-avatar cl-avatar--active">MA</div>
          <div className="cl-row__main">
            <div className="cl-row__top">
              <div className="cl-row__name">Matthew Addition</div>
              <div className="cl-row__amt stamp">$24K</div>
            </div>
            <div className="cl-row__bot">
              <span className="cl-row__chip cl-row__chip--active">ACTIVE</span>
              <span className="cl-row__kind">Residential addition</span>
              <span style={{ marginLeft: 'auto' }} className="cl-row__last">2d ago</span>
            </div>
          </div>
        </button>

        <button className="cl-row">
          <div className="cl-avatar cl-avatar--active">JR</div>
          <div className="cl-row__main">
            <div className="cl-row__top">
              <div className="cl-row__name">Jeff Roy</div>
              <div className="cl-row__amt stamp">$18K</div>
            </div>
            <div className="cl-row__bot">
              <span className="cl-row__chip cl-row__chip--active">ACTIVE</span>
              <span className="cl-row__kind">Roof &amp; exterior</span>
              <span style={{ marginLeft: 'auto' }} className="cl-row__last">today</span>
            </div>
          </div>
        </button>

        <div className="cl-section-lbl"><span style={{ color: '#E08B7A' }}>Owes balance</span></div>

        <button className="cl-row" style={{ borderColor: 'rgba(224,139,122,0.18)' }}>
          <div className="cl-avatar cl-avatar--owes">HN</div>
          <div className="cl-row__main">
            <div className="cl-row__top">
              <div className="cl-row__name">Heather Neighbor</div>
              <div className="cl-row__amt stamp" style={{ color: '#E08B7A' }}>$12.4K</div>
            </div>
            <div className="cl-row__bot">
              <span className="cl-row__chip cl-row__chip--owes">42d OVERDUE</span>
              <span className="cl-row__kind">Deck rebuild</span>
              <span style={{ marginLeft: 'auto' }} className="cl-row__last">no reply 8d</span>
            </div>
          </div>
        </button>

        <div className="bot-spacer"></div>
      </div>

      <BottomNav active="clients" />
    </div>
  );
};

// ============================================================
// 02 · NEW LEAD — voice-first AI capture
// ============================================================
window.NewLeadScreen = function NewLeadScreen() {
  const [recording, setRecording] = React.useState(true);
  return (
    <div className="screen lead-screen">
      <div className="lead-handle"></div>

      <div className="lead-head">
        <div>
          <div className="lead-head__step">NEW LEAD · STEP 1 OF 3</div>
          <h1 className="lead-head__title">Capture lead</h1>
        </div>
        <button className="icon-btn" aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </div>

      <div className="lead-progress">
        <span className="is-on"></span><span></span><span></span>
      </div>

      <div className="screen__body no-scroll" style={{ paddingBottom: 180 }}>
        <div className="lead-pro-mic">
          <button className={`lead-pro-mic__btn ${recording ? 'is-on' : ''}`} onClick={() => setRecording(!recording)}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 0 1-14 0M12 19v3"/></svg>
          </button>
          <div className="lead-pro-mic__main">
            <div className="lead-pro-mic__lbl">
              <span className="lead-pro-mic__pulse"></span>
              RECORDING
              <b>0:42</b>
            </div>
            <div className="lead-pro-mic__title">Capturing Sarah's call</div>
            <div className="lead-pro-mic__hint">Tap mic to stop · transcript live below</div>
          </div>
        </div>

        <div className="transcript-rail">
          <button className="transcript-rail__play">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="m6 4 14 8L6 20z"/></svg>
          </button>
          <div className="transcript-rail__main">
            <div className="transcript-rail__t">"Hey it's Sarah Whitfield, I got your number from Tom at MMC…"</div>
            <div className="transcript-rail__m">87 WORDS · 1:42 · 9 FIELDS DETECTED</div>
          </div>
          <button className="transcript-rail__expand">View</button>
        </div>

        <div className="section-lbl">
          <span>Lead details</span>
          <span className="section-lbl__hint">tap to edit</span>
        </div>

        <div className="lead-fields">
          <div className="lead-fields__head">
            <div className="lead-fields__icn">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="8" r="4"/><path d="M4 21v-2a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v2"/></svg>
            </div>
            <div className="lead-fields__t">Contact <span>· from voice</span></div>
            <button className="lead-fields__edit">Edit</button>
          </div>
          <div className="lead-fields__row">
            <div className="lead-fields__k">Name</div>
            <div className="lead-fields__v">Sarah Whitfield</div>
          </div>
          <div className="lead-fields__row">
            <div className="lead-fields__k">Phone</div>
            <div className="lead-fields__v">(615) 555-0184</div>
          </div>
          <div className="lead-fields__row">
            <div className="lead-fields__k">Address</div>
            <div className="lead-fields__v">412 Linden Ct, Brentwood</div>
          </div>
          <div className="lead-fields__row">
            <div className="lead-fields__k">Referred by</div>
            <div className="lead-fields__v">Tom Mendelson · MMC<span className="lead-fields__tag">REPEAT</span></div>
          </div>
        </div>

        <div className="lead-fields" style={{ marginTop: 10 }}>
          <div className="lead-fields__head">
            <div className="lead-fields__icn">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
            <div className="lead-fields__t">Project</div>
            <button className="lead-fields__edit">Edit</button>
          </div>
          <div className="lead-fields__row">
            <div className="lead-fields__k">Type</div>
            <div className="lead-fields__v">Deck rebuild + pergola</div>
          </div>
          <div className="lead-fields__row">
            <div className="lead-fields__k">Budget</div>
            <div className="lead-fields__v">$30K – $40K</div>
          </div>
          <div className="lead-fields__row">
            <div className="lead-fields__k">Timing</div>
            <div className="lead-fields__v">Within 2 weeks</div>
          </div>
          <div className="lead-fields__row">
            <div className="lead-fields__k">Source</div>
            <div className="lead-fields__v is-empty">Not specified</div>
          </div>
        </div>

        <div className="section-lbl" style={{ marginTop: 16 }}>Scope tags</div>
        <div className="lead-chips" style={{ margin: '0 16px' }}>
          <button className="lead-chip is-on">Deck rebuild</button>
          <button className="lead-chip is-on">Pergola</button>
          <button className="lead-chip">Stairs</button>
          <button className="lead-chip">Railing</button>
          <button className="lead-chip">+ Add</button>
        </div>
      </div>

      <div className="cta-bar">
        <button className="cta-bar__secondary" aria-label="Save draft">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/></svg>
        </button>
        <button className="cta-bar__primary">
          Save & schedule visit
          <Caret size={12}/>
        </button>
      </div>
    </div>
  );
};

// ============================================================
// 03 · NOTES & CAPTURE
// ============================================================
window.NotesScreen = function NotesScreen() {
  return (
    <div className="screen">
      <div className="app-head app-head--titled">
        <div className="app-head__title-block">
          <div className="eyebrow eyebrow--gold">MMC · Summer Creek</div>
          <h1 className="page-h1">Notes</h1>
        </div>
        <div className="app-head__actions">
          <button className="icon-btn" aria-label="Filter">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M3 6h18M6 12h12M10 18h4"/></svg>
          </button>
        </div>
      </div>

      <div className="screen__body no-scroll" style={{ paddingBottom: 100 }}>
        {/* Compact recording rail — not the hero */}
        <div className="transcript-rail" style={{ marginTop: 4 }}>
          <button className="transcript-rail__play">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><rect x="6" y="5" width="3" height="14" fill="currentColor" stroke="none"/><rect x="15" y="5" width="3" height="14" fill="currentColor" stroke="none"/></svg>
          </button>
          <div className="transcript-rail__main">
            <div className="transcript-rail__t">"Walked the rail today, noticed ~8' of bottom plate is rotted…"</div>
            <div className="transcript-rail__m">RECORDING · 1:24 · 3 ITEMS DETECTED</div>
          </div>
          <button className="transcript-rail__expand">Expand</button>
        </div>

        {/* Quick stat rail — at-a-glance counts */}
        <div className="notes-quick-rail">
          <button className="notes-quick-rail__btn is-act">
            <b>3</b><span>Actions</span>
          </button>
          <button className="notes-quick-rail__btn is-mat">
            <b>2</b><span>Materials</span>
          </button>
          <button className="notes-quick-rail__btn is-risk">
            <b>1</b><span>Risks</span>
          </button>
          <button className="notes-quick-rail__btn">
            <b>4</b><span>Recent</span>
          </button>
        </div>

        {/* Action items — clean stacked card */}
        <div className="parse-card-v2">
          <div className="parse-card-v2__head">
            <div className="parse-card-v2__icn">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <div className="parse-card-v2__t">Action items</div>
            <div className="parse-card-v2__count">3</div>
          </div>
          <div className="parse-card-v2__rows">
            <div className="parse-card-v2__row">
              <div className="parse-card-v2__row-chk"></div>
              <div className="parse-card-v2__row-main">
                <div className="parse-card-v2__row-t">Replace <b>~8' rotted plate</b> at SW corner</div>
                <div className="parse-card-v2__row-m">Before button-up · est 4 hrs</div>
              </div>
            </div>
            <div className="parse-card-v2__row">
              <div className="parse-card-v2__row-chk"></div>
              <div className="parse-card-v2__row-main">
                <div className="parse-card-v2__row-t">Quote <b>2 sconces</b> · $240 ea installed</div>
                <div className="parse-card-v2__row-m">Add to change order #2</div>
              </div>
            </div>
            <div className="parse-card-v2__row">
              <div className="parse-card-v2__row-chk"></div>
              <div className="parse-card-v2__row-main">
                <div className="parse-card-v2__row-t">Call <b>Lonnie · Pro Lumber</b> AM</div>
                <div className="parse-card-v2__row-m">Reorder cedar 5/4×6</div>
              </div>
            </div>
          </div>
        </div>

        {/* Materials */}
        <div className="parse-card-v2">
          <div className="parse-card-v2__head">
            <div className="parse-card-v2__icn is-mat">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M3 7v10h18V7M3 7l3-4h12l3 4M9 11h6"/></svg>
            </div>
            <div className="parse-card-v2__t">Materials</div>
            <div className="parse-card-v2__count">2</div>
          </div>
          <div className="parse-card-v2__rows">
            <div className="parse-card-v2__row">
              <div className="parse-card-v2__row-main" style={{ marginLeft: 26 }}>
                <div className="parse-card-v2__row-t">Cedar 5/4 × 6 × 12' <b>· qty TBD</b></div>
                <div className="parse-card-v2__row-m">Pro Lumber</div>
              </div>
            </div>
            <div className="parse-card-v2__row">
              <div className="parse-card-v2__row-main" style={{ marginLeft: 26 }}>
                <div className="parse-card-v2__row-t">Wall sconces · <b>×2</b></div>
                <div className="parse-card-v2__row-m">Match existing — confirm w/ client</div>
              </div>
            </div>
          </div>
        </div>

        {/* Risks */}
        <div className="parse-card-v2">
          <div className="parse-card-v2__head">
            <div className="parse-card-v2__icn is-risk">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m12 9 .01 4M12 17h.01M10.3 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>
            </div>
            <div className="parse-card-v2__t">Risks &amp; flags</div>
            <div className="parse-card-v2__count">1</div>
          </div>
          <div className="parse-card-v2__rows">
            <div className="parse-card-v2__row">
              <div className="parse-card-v2__row-main" style={{ marginLeft: 26 }}>
                <div className="parse-card-v2__row-t">Rotted plate may signal <b>broader water intrusion</b></div>
                <div className="parse-card-v2__row-m">Probe east + north corners before pricing</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bot-spacer"></div>
      </div>

      {/* Sticky primary CTA */}
      <div className="cta-bar">
        <button className="cta-bar__secondary" aria-label="Type">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
        </button>
        <button className="cta-bar__primary">
          Save 6 items to job
          <Caret size={12}/>
        </button>
      </div>

      <BottomNav active="more" />
    </div>
  );
};
