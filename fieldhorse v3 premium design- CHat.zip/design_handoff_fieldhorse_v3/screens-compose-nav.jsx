/* global React */

const Caret3 = ({ size = 12 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
);

// ============================================================
// 07 · AI COMPOSE — DRAFT-AS-HERO
// The generated draft is the visual centerpiece. Channel,
// tone, and length are adjusters that reshape the hero.
// ============================================================
window.ComposeScreen = function ComposeScreen() {
  const [channel, setChannel] = React.useState('text');
  const [tone, setTone] = React.useState('warm');
  const [length, setLength] = React.useState('right');

  const ChannelTab = ({ id, label, icon }) => (
    <button className={`cmp2-channel ${channel === id ? 'is-on' : ''}`} onClick={() => setChannel(id)}>
      {icon}
      <span>{label}</span>
    </button>
  );

  return (
    <div className="screen">
      <div className="cmp2-head">
        <button className="icon-btn" aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
        <div className="cmp2-head__title">
          <div className="cmp2-head__eyebrow">AI COMPOSE · FOLLOW UP · PAYMENT</div>
          <div className="cmp2-head__h">Heather Neighbor</div>
        </div>
        <button className="icon-btn" aria-label="More">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/></svg>
        </button>
      </div>

      <div className="cmp2-channels">
        <ChannelTab id="text" label="Text" icon={
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        }/>
        <ChannelTab id="email" label="Email" icon={
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></svg>
        }/>
        <ChannelTab id="voice" label="Voicemail" icon={
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 0 1-14 0M12 19v3"/></svg>
        }/>
      </div>

      <div className="screen__body no-scroll" style={{ paddingBottom: 110 }}>

        {/* HERO — the draft itself */}
        {channel === 'text' && (
          <div className="cmp2-hero cmp2-hero--text">
            <div className="cmp2-hero__chrome">
              <div className="cmp2-hero__phone-bar">
                <span>9:42</span>
                <span className="cmp2-hero__phone-icns">
                  <svg width="14" height="9" viewBox="0 0 17 11" fill="currentColor"><path d="M1 8h2v2H1zM5 6h2v4H5zM9 4h2v6H9zM13 1h2v9h-2z"/></svg>
                  <svg width="20" height="9" viewBox="0 0 24 11"><rect x="1" y="1" width="20" height="9" rx="2.5" stroke="currentColor" strokeOpacity="0.6" fill="none"/><rect x="2.5" y="2.5" width="15" height="6" rx="1" fill="currentColor"/></svg>
                </span>
              </div>
              <div className="cmp2-hero__phone-to">
                <div className="cl-avatar cl-avatar--gold" style={{ width: 28, height: 28, fontSize: 11 }}>HN</div>
                <div>
                  <div className="cmp2-hero__phone-n">Heather Neighbor</div>
                  <div className="cmp2-hero__phone-s">+1 (615) 555-0241</div>
                </div>
              </div>
            </div>
            <div className="cmp2-hero__msg">
              <div className="cmp2-hero__date stamp">TUE · 9:42 AM</div>
              <div className="cmp2-hero__bubble">
                Hey Heather, just circling back on invoice <b>#2024-061-3</b> for <b>$12,400</b> on the deck rebuild. I know things get busy.
                {'\n\n'}
                Happy to swing by <b>Thursday afternoon</b> to walk any final punch items if that helps. — Jesse
              </div>
              <div className="cmp2-hero__bubble-meta">
                <span><b className="stamp">42</b> words · <b className="stamp">1</b> SMS</span>
              </div>
            </div>
          </div>
        )}

        {channel === 'email' && (
          <div className="cmp2-hero cmp2-hero--email">
            <div className="cmp2-hero__email-head">
              <div className="cmp2-hero__email-row"><span>FROM</span><b>Jesse Parker · Parker Construction</b></div>
              <div className="cmp2-hero__email-row"><span>TO</span><b>Heather Neighbor &lt;hneighbor@gmail.com&gt;</b></div>
              <div className="cmp2-hero__email-subject">Quick follow-up on Summer Creek deck</div>
            </div>
            <pre className="cmp2-hero__email-body">{`Heather,

Hope you're doing well. Wanted to circle back on the
final invoice for the deck rebuild — #2024-061-3 for
$12,400 — which is now 42 days out.

If anything's holding things up on your end I'd rather
hear it directly. Happy to swing by Thursday afternoon
to walk the finish work and answer any questions.

— Jesse Parker
   Parker Construction
   (615) 555-0100`}</pre>
            <div className="cmp2-hero__bubble-meta cmp2-hero__bubble-meta--email">
              <span><b className="stamp">86</b> words · ~30 sec read</span>
            </div>
          </div>
        )}

        {channel === 'voice' && (
          <div className="cmp2-hero cmp2-hero--voice">
            <div className="cmp2-hero__voice-card">
              <button className="cmp2-hero__voice-play">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
              </button>
              <svg className="cmp2-hero__voice-wave" viewBox="0 0 240 36" preserveAspectRatio="none">
                {Array.from({ length: 64 }).map((_, i) => {
                  const h = 5 + Math.abs(Math.sin(i * 0.42) + Math.sin(i * 0.13)) * 13;
                  return <rect key={i} x={i * 3.6} y={(36 - h) / 2} width="2" height={h} rx="1" fill="var(--gold-bright)" opacity={i < 18 ? 1 : 0.45}/>;
                })}
              </svg>
              <div className="cmp2-hero__voice-time stamp">0:00 / 0:24</div>
            </div>
            <div className="cmp2-hero__voice-script">
              <div className="cmp2-hero__voice-lbl">SCRIPT · YOUR VOICE CLONED FROM 12 PRIOR CALLS</div>
              "Hey Heather, it's Jesse — just wanted to circle back on the final deck invoice. I'll be on the road tomorrow but I can swing by Thursday afternoon to walk the punch list with you. Give me a call back when you get a chance."
            </div>
            <div className="cmp2-hero__bubble-meta cmp2-hero__bubble-meta--email">
              <span><b className="stamp">0:24</b> · 48 words · natural pacing</span>
            </div>
          </div>
        )}

        {/* AI REASONING — what facts the draft used */}
        <div className="cmp2-facts">
          <div className="cmp2-facts__lbl">USED 4 FACTS FROM THIS CLIENT</div>
          <div className="cmp2-facts__row">
            <span className="cmp2-fact">Invoice #2024-061-3</span>
            <span className="cmp2-fact">$12,400 owed</span>
            <span className="cmp2-fact cmp2-fact--alert">42d overdue</span>
            <span className="cmp2-fact">Tom referral</span>
          </div>
        </div>

        {/* ADJUSTERS — these reshape the hero */}
        <div className="cmp2-adjust">
          <div className="cmp2-adjust__group">
            <div className="cmp2-adjust__lbl">TONE</div>
            <div className="cmp2-adjust__chips">
              {['warm','direct','formal','urgent'].map(t => (
                <button key={t} className={`cmp2-chip ${tone === t ? 'is-on' : ''}`} onClick={() => setTone(t)}>{t}</button>
              ))}
            </div>
          </div>
          <div className="cmp2-adjust__group">
            <div className="cmp2-adjust__lbl">LENGTH</div>
            <div className="cmp2-adjust__chips">
              {[['short','Short'],['right','Just right'],['long','Detailed']].map(([k,l]) => (
                <button key={k} className={`cmp2-chip ${length === k ? 'is-on' : ''}`} onClick={() => setLength(k)}>{l}</button>
              ))}
            </div>
          </div>
        </div>

        <div className="bot-spacer"></div>
      </div>

      {/* CTA bar */}
      <div className="cta-bar">
        <button className="cta-bar__secondary" aria-label="Regenerate">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
        </button>
        <button className="cta-bar__primary">
          {channel === 'voice' ? 'Send voicemail' : channel === 'email' ? 'Send email' : 'Send text'}
          <Caret3 size={12}/>
        </button>
      </div>
    </div>
  );
};

// ============================================================
// 08 · NAV / MENU
// ============================================================
window.NavScreen = function NavScreen() {
  return (
    <div className="screen nav-screen">
      <div className="nav-handle"></div>

      <div className="screen__body no-scroll" style={{ paddingTop: 6, paddingBottom: 30 }}>
        <div className="nav-ws">
          <div className="nav-ws__brand">
            <div className="nav-ws__mark">PC</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="nav-ws__co">PARKER CONSTRUCTION</div>
              <div className="nav-ws__tag">FIELDHORSE · OWNER</div>
            </div>
            <button className="icon-btn nav-ws__close" aria-label="Close">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
            </button>
          </div>
          <div className="nav-ws__row">
            <div className="nav-ws__cell">
              <div className="nav-ws__lbl">PIPELINE</div>
              <div className="nav-ws__amt stamp">$136K</div>
            </div>
            <div className="nav-ws__div"></div>
            <div className="nav-ws__cell">
              <div className="nav-ws__lbl">OWED</div>
              <div className="nav-ws__amt stamp" style={{ color: '#E08B7A' }}>$24.3K</div>
            </div>
            <div className="nav-ws__div"></div>
            <div className="nav-ws__cell">
              <div className="nav-ws__lbl">YTD</div>
              <div className="nav-ws__amt stamp">$684K</div>
            </div>
          </div>
        </div>

        <div className="nav-group-lbl">QUICK CREATE</div>
        <div className="nav-grid">
          <button className="nav-tile">
            <div className="nav-tile__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>
            </div>
            <div className="nav-tile__t">New lead</div>
            <div className="nav-tile__s">Voice or form</div>
          </button>
          <button className="nav-tile">
            <div className="nav-tile__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h4"/></svg>
            </div>
            <div className="nav-tile__t">New estimate</div>
            <div className="nav-tile__s">AI builder</div>
          </button>
          <button className="nav-tile">
            <div className="nav-tile__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
            <div className="nav-tile__t">New invoice</div>
            <div className="nav-tile__s">From job phase</div>
          </button>
          <button className="nav-tile">
            <div className="nav-tile__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </div>
            <div className="nav-tile__t">Capture note</div>
            <div className="nav-tile__s">Site walk · voice</div>
          </button>
        </div>

        <div className="nav-group-lbl">WORKSPACE</div>
        <div className="nav-list">
          <button className="nav-row">
            <div className="nav-row__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/></svg>
            </div>
            <div className="nav-row__main">
              <div className="nav-row__t">Jobs &amp; pipeline</div>
              <div className="nav-row__s">11 open · 4 active</div>
            </div>
            <span className="nav-row__tag">11</span>
            <Caret3 size={12}/>
          </button>
          <button className="nav-row">
            <div className="nav-row__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>
            </div>
            <div className="nav-row__main">
              <div className="nav-row__t">Clients</div>
              <div className="nav-row__s">47 · 3 owe balance</div>
            </div>
            <Caret3 size={12}/>
          </button>
          <button className="nav-row">
            <div className="nav-row__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
            </div>
            <div className="nav-row__main">
              <div className="nav-row__t">Schedule</div>
              <div className="nav-row__s">4 events today</div>
            </div>
            <Caret3 size={12}/>
          </button>
          <button className="nav-row">
            <div className="nav-row__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
            <div className="nav-row__main">
              <div className="nav-row__t">Money owed</div>
              <div className="nav-row__s">$24.3K outstanding</div>
            </div>
            <span className="nav-row__tag nav-row__tag--alert">1</span>
            <Caret3 size={12}/>
          </button>
        </div>

        <div className="nav-group-lbl">TOOLS</div>
        <div className="nav-list">
          <button className="nav-row">
            <div className="nav-row__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3 2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.6 9.1l5.8-.8L12 3z"/></svg>
            </div>
            <div className="nav-row__main">
              <div className="nav-row__t">AI Compose</div>
              <div className="nav-row__s">Text · email · voicemail</div>
            </div>
            <Caret3 size={12}/>
          </button>
          <button className="nav-row">
            <div className="nav-row__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </div>
            <div className="nav-row__main">
              <div className="nav-row__t">Notes &amp; capture</div>
              <div className="nav-row__s">Voice → action items</div>
            </div>
            <Caret3 size={12}/>
          </button>
          <button className="nav-row">
            <div className="nav-row__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="m7 14 4-4 4 4 5-5"/></svg>
            </div>
            <div className="nav-row__main">
              <div className="nav-row__t">Reports</div>
              <div className="nav-row__s">YTD · margin · pipeline</div>
            </div>
            <Caret3 size={12}/>
          </button>
          <button className="nav-row">
            <div className="nav-row__icn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.36.21.78.32 1.21.33H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
            </div>
            <div className="nav-row__main">
              <div className="nav-row__t">Settings</div>
              <div className="nav-row__s">Crew · billing · automations</div>
            </div>
            <Caret3 size={12}/>
          </button>
        </div>

        <div className="nav-group-lbl">ACCOUNT</div>
        <div className="nav-acct">
          <div className="cl-avatar cl-avatar--gold" style={{ width: 38, height: 38, fontSize: 14 }}>JP</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="nav-acct__n">Jesse Parker</div>
            <div className="nav-acct__sub">Owner · jesse@parkerco.com</div>
          </div>
          <button className="icon-btn" aria-label="Sign out">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>
          </button>
        </div>

      </div>
    </div>
  );
};
