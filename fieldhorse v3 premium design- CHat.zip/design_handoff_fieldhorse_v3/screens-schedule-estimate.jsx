/* global React */

// ============================================================
// SCHEDULE — premium dispatch board (refined)
// ============================================================
window.ScheduleScreen = function ScheduleScreen() {
  const days = [
    { d: 'MON', n: '27' },
    { d: 'TUE', n: '28', on: true },
    { d: 'WED', n: '29', pip: true },
    { d: 'THU', n: '30', pip: true },
    { d: 'FRI', n: '01' },
    { d: 'SAT', n: '02' },
    { d: 'SUN', n: '03' },
  ];
  const [view, setView] = React.useState('all');

  return (
    <div className="screen">
      <div className="app-head app-head--titled">
        <div className="app-head__title-block">
          <div className="eyebrow eyebrow--gold">Tue · Apr 28 · 4 visits</div>
          <h1 className="page-h1">Today</h1>
        </div>
        <div className="app-head__actions">
          <button className="icon-btn" aria-label="Search">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
          </button>
          <button className="icon-btn" aria-label="Add">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>
          </button>
        </div>
      </div>

      <div className="screen__body no-scroll" style={{ paddingBottom: 100 }}>
        {/* Cleaner date strip */}
        <div className="dispatch-strip">
          {days.map(d => (
            <button key={d.n} className={`dispatch-day ${d.on ? 'is-today' : ''}`}>
              <span className="dispatch-day__dow">{d.d}</span>
              <span className="dispatch-day__num">{d.n}</span>
              {(d.on || d.pip) && <span className="dispatch-day__pip"></span>}
            </button>
          ))}
        </div>

        {/* State pill toggle */}
        <div className="dispatch-state">
          <button className={`dispatch-state__opt ${view === 'all' ? 'is-on' : ''}`} onClick={() => setView('all')}>All <b>4</b></button>
          <button className={`dispatch-state__opt ${view === 'live' ? 'is-on' : ''}`} onClick={() => setView('live')}>Live <b>1</b></button>
          <button className={`dispatch-state__opt ${view === 'up' ? 'is-on' : ''}`} onClick={() => setView('up')}>Upcoming <b>3</b></button>
          <button className={`dispatch-state__opt ${view === 'done' ? 'is-on' : ''}`} onClick={() => setView('done')}>Done <b>0</b></button>
        </div>

        {/* Live event */}
        <div className="dispatch-card is-live">
          <div className="dispatch-card__top">
            <div className="dispatch-card__time">
              <div className="dispatch-card__hr">8:15</div>
              <div className="dispatch-card__ap">AM</div>
            </div>
            <div className="dispatch-card__body">
              <div className="dispatch-card__head-row">
                <div>
                  <div className="dispatch-card__title">Roll painting · framing closeout</div>
                  <div className="dispatch-card__sub">MMC Properties · Summer Creek</div>
                </div>
                <span className="dispatch-state-pill dispatch-state-pill--live">LIVE</span>
              </div>
              <div className="dispatch-card__addr">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                412 Summer Creek Dr
              </div>
            </div>
          </div>
          <div className="dispatch-card__crew">
            <div className="dispatch-card__crew-avs">
              <div className="dispatch-av dispatch-av--gold">TM</div>
              <div className="dispatch-av">MC</div>
              <div className="dispatch-av">JE</div>
            </div>
            <div className="dispatch-card__crew-text">
              <b>Tim, Marco, Jeff</b> · on site since 8:12 AM
            </div>
          </div>
        </div>

        {/* Upcoming events */}
        <div className="dispatch-card">
          <div className="dispatch-card__top">
            <div className="dispatch-card__time">
              <div className="dispatch-card__hr">10:30</div>
              <div className="dispatch-card__ap">AM</div>
            </div>
            <div className="dispatch-card__body">
              <div className="dispatch-card__head-row">
                <div>
                  <div className="dispatch-card__title">Material delivery</div>
                  <div className="dispatch-card__sub">Matthew Addition · Bishop Lumber</div>
                </div>
                <span className="dispatch-state-pill dispatch-state-pill--up">UP NEXT</span>
              </div>
              <div className="dispatch-card__addr">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="3" width="15" height="13" rx="1"/><path d="M16 8h4l3 3v5h-7"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
                Drywall + tile · ETA 18 min
              </div>
            </div>
          </div>
        </div>

        <div className="dispatch-card">
          <div className="dispatch-card__top">
            <div className="dispatch-card__time">
              <div className="dispatch-card__hr">2:00</div>
              <div className="dispatch-card__ap">PM</div>
            </div>
            <div className="dispatch-card__body">
              <div className="dispatch-card__head-row">
                <div>
                  <div className="dispatch-card__title">Roof inspection walkthrough</div>
                  <div className="dispatch-card__sub">Jeff Roy · 1830 Belle Meade</div>
                </div>
                <span className="dispatch-state-pill dispatch-state-pill--up">UPCOMING</span>
              </div>
              <div className="dispatch-card__addr">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>
                With client · prep estimate
              </div>
            </div>
          </div>
          <div className="dispatch-card__crew">
            <div className="dispatch-card__crew-avs">
              <div className="dispatch-av dispatch-av--gold">JP</div>
            </div>
            <div className="dispatch-card__crew-text">
              <b>You</b> · solo visit
            </div>
          </div>
        </div>

        <div className="dispatch-card">
          <div className="dispatch-card__top">
            <div className="dispatch-card__time">
              <div className="dispatch-card__hr">4:30</div>
              <div className="dispatch-card__ap">PM</div>
            </div>
            <div className="dispatch-card__body">
              <div className="dispatch-card__head-row">
                <div>
                  <div className="dispatch-card__title">Site visit · concrete restoration</div>
                  <div className="dispatch-card__sub">Lily Grace North · estimate prep</div>
                </div>
                <span className="dispatch-state-pill dispatch-state-pill--up">UPCOMING</span>
              </div>
              <div className="dispatch-card__addr">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                11 mi · 22 min drive
              </div>
            </div>
          </div>
        </div>

        <div className="bot-spacer"></div>
      </div>

      <BottomNav active="schedule" />
    </div>
  );
};

// ============================================================
// ESTIMATE — Builder + Proposal Preview (split view)
// ============================================================
window.EstimateScreen = function EstimateScreen() {
  const [view, setView] = React.useState('build'); // build | preview
  const [margin, setMargin] = React.useState(28);
  const subtotal = 24400;
  const tax = Math.round(subtotal * 0.0725);
  const grand = subtotal + tax;
  const profit = Math.round(subtotal * (margin / 100));

  return (
    <div className="screen">
      <div className="app-head app-head--titled">
        <div className="app-head__title-block">
          <div className="eyebrow eyebrow--gold">EST-2026-0231 · Draft</div>
          <h1 className="page-h1">Roof, deck, chimney</h1>
          <div className="page-sub">Jeff Roy · 1830 Belle Meade Blvd</div>
        </div>
        <div className="app-head__actions">
          <button className="icon-btn" aria-label="More">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/></svg>
          </button>
        </div>
      </div>

      {/* Builder ↔ Preview tab switch */}
      <div className="dispatch-state" style={{ margin: '4px 16px 14px', width: 'fit-content' }}>
        <button className={`dispatch-state__opt ${view === 'build' ? 'is-on' : ''}`} onClick={() => setView('build')}>
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
          Builder
        </button>
        <button className={`dispatch-state__opt ${view === 'preview' ? 'is-on' : ''}`} onClick={() => setView('preview')}>
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>
          Proposal preview
        </button>
      </div>

      <div className="screen__body no-scroll" style={{ paddingBottom: 100 }}>
        {view === 'build' && (
          <>
            {/* Scope input — voice or type */}
            <div className="est-input-card">
              <div className="est-input-card__head">
                <div className="est-input-card__lbl">Scope</div>
                <button className="est-input-card__voice">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 0 1-14 0M12 19v3"/></svg>
                  VOICE
                </button>
              </div>
              <div className="est-input-card__body">
                Tear off existing 2,400 sf roof, install GAF Timberline architectural shingle. Rebuild 320 sf composite deck w/ TimberTech. Repoint chimney + new stainless cap.
              </div>
            </div>

            {/* Line items */}
            <div className="section-lbl">
              <span>Line items</span>
              <span className="section-lbl__hint">tap any row to edit</span>
            </div>

            <div className="est-input-card" style={{ marginBottom: 14 }}>
              <div className="est-line">
                <div className="est-line__num">01</div>
                <div className="est-line__main">
                  <div className="est-line__t">Roof tear-off &amp; replace</div>
                  <div className="est-line__sub">2,400 sf · GAF Timberline architectural</div>
                </div>
                <div className="est-line__amt">$14,200</div>
              </div>
              <div className="est-line">
                <div className="est-line__num">02</div>
                <div className="est-line__main">
                  <div className="est-line__t">Composite deck rebuild</div>
                  <div className="est-line__sub">320 sf · TimberTech · railing incl.</div>
                </div>
                <div className="est-line__amt">$6,800</div>
              </div>
              <div className="est-line">
                <div className="est-line__num">03</div>
                <div className="est-line__main">
                  <div className="est-line__t">Chimney repoint &amp; cap</div>
                  <div className="est-line__sub">22 ft · stainless cap · Type N mortar</div>
                </div>
                <div className="est-line__amt">$2,400</div>
              </div>
              <div className="est-line">
                <div className="est-line__num">04</div>
                <div className="est-line__main">
                  <div className="est-line__t">Materials &amp; disposal</div>
                  <div className="est-line__sub">Dumpster · permit · cleanup</div>
                </div>
                <div className="est-line__amt">$1,000</div>
              </div>
              <div style={{ padding: 10 }}>
                <button className="est-add-line">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>
                  Add line item
                </button>
              </div>
            </div>

            {/* Margin */}
            <div className="est-margin-v2">
              <div className="est-margin-v2__head">
                <div className="est-margin-v2__lbl">Margin target</div>
                <div className="est-margin-v2__pct">{margin}<span>%</span></div>
              </div>
              <div className="est-margin__slider">
                <div className="est-margin__track"></div>
                <div className="est-margin__fill" style={{ width: `${((margin - 15) / 35) * 100}%` }}></div>
                <input type="range" min="15" max="50" value={margin} onChange={(e) => setMargin(Number(e.target.value))}/>
                <svg width="20" height="20" viewBox="0 0 20 20" style={{
                  position: 'absolute', top: '50%',
                  left: `calc(${((margin - 15) / 35) * 100}% - 10px)`,
                  transform: 'translateY(-50%)',
                  filter: 'drop-shadow(0 4px 10px rgba(201,150,58,0.5))',
                  pointerEvents: 'none',
                }}>
                  <circle cx="10" cy="10" r="9" fill="url(#estg2)"/>
                  <defs><linearGradient id="estg2" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#E8B865"/><stop offset="100%" stopColor="#C9963A"/></linearGradient></defs>
                </svg>
              </div>
              <div className="est-margin-v2__totals">
                <div className="est-margin-v2__cell">
                  <div className="est-margin-v2__cell-lbl">Client total</div>
                  <div className="est-margin-v2__cell-amt">${grand.toLocaleString()}</div>
                </div>
                <div className="est-margin-v2__cell">
                  <div className="est-margin-v2__cell-lbl">Your profit</div>
                  <div className="est-margin-v2__cell-amt is-gold">${profit.toLocaleString()}</div>
                </div>
              </div>
            </div>
          </>
        )}

        {view === 'preview' && (
          <>
            {/* Letterhead — proposal feel */}
            <section className="est-letterhead" style={{ marginTop: 4 }}>
              <div className="est-letterhead__top">
                <div className="est-letterhead__logo">PC</div>
                <div className="est-letterhead__co">
                  <div className="est-letterhead__co-name">PARKER</div>
                  <div className="est-letterhead__co-tag">Construction Co. · Murfreesboro, TN</div>
                </div>
                <span className="pill pill--gold">Draft</span>
              </div>
              <div className="est-letterhead__title">
                <div className="eyebrow">PROPOSAL</div>
                <h2 style={{ margin: 0, fontSize: 24, fontWeight: 600, letterSpacing: '-0.02em', color: 'var(--ink)' }}>Roof, deck &amp; chimney</h2>
              </div>
              <div className="est-letterhead__meta">
                <div>
                  <div className="est-letterhead__lbl">CLIENT</div>
                  <div className="est-letterhead__val">Jeff Roy</div>
                </div>
                <div>
                  <div className="est-letterhead__lbl">VALID UNTIL</div>
                  <div className="est-letterhead__val">May 28, 2026</div>
                </div>
                <div>
                  <div className="est-letterhead__lbl">PROPOSAL #</div>
                  <div className="est-letterhead__val stamp">EST-0231</div>
                </div>
              </div>
            </section>

            <section className="block">
              <div className="block__head">
                <div className="eyebrow">Scope · 4 line items</div>
              </div>
              <div className="est-lines">
                {[
                  ['01', 'Roof tear-off & replace', '2,400 sf · architectural shingle · GAF Timberline', '$14,200'],
                  ['02', 'Composite deck rebuild', '320 sf · TimberTech · railing included', '$6,800'],
                  ['03', 'Chimney repoint & cap', '22 ft · stainless cap · Type N mortar', '$2,400'],
                  ['04', 'Materials & disposal', 'Dumpster · permit · cleanup', '$1,000'],
                ].map(([n, t, s, a]) => (
                  <div key={n} className="est-line">
                    <div className="est-line__num stamp">{n}</div>
                    <div className="est-line__main">
                      <div className="est-line__title">{t}</div>
                      <div className="est-line__meta">{s}</div>
                    </div>
                    <div className="est-line__amt stamp">{a}</div>
                  </div>
                ))}
              </div>
            </section>

            <section className="block est-totals">
              <div className="est-totals__row">
                <span>Subtotal</span>
                <span className="stamp">${subtotal.toLocaleString()}</span>
              </div>
              <div className="est-totals__row">
                <span>Tax · 7.25%</span>
                <span className="stamp">${tax.toLocaleString()}</span>
              </div>
              <div className="est-totals__row est-totals__row--grand">
                <div>
                  <div className="est-totals__lbl">Total</div>
                  <div className="est-totals__sub">Margin <span className="stamp">{margin}%</span> · Profit <span className="stamp">${profit.toLocaleString()}</span></div>
                </div>
                <div className="est-totals__grand stamp">${grand.toLocaleString()}</div>
              </div>
            </section>

            <section className="block est-terms">
              <div className="block__head">
                <div className="eyebrow">Payment terms</div>
              </div>
              <div className="est-terms__row">
                <div className="est-terms__pct stamp">25%</div>
                <div className="est-terms__main">
                  <div className="est-terms__title">Deposit on signing</div>
                  <div className="est-terms__meta">Due before crew mobilizes</div>
                </div>
                <div className="est-terms__amt stamp">${Math.round(grand * 0.25).toLocaleString()}</div>
              </div>
              <div className="est-terms__row">
                <div className="est-terms__pct stamp">50%</div>
                <div className="est-terms__main">
                  <div className="est-terms__title">Mid-project</div>
                  <div className="est-terms__meta">Roof complete · materials delivered</div>
                </div>
                <div className="est-terms__amt stamp">${Math.round(grand * 0.5).toLocaleString()}</div>
              </div>
              <div className="est-terms__row">
                <div className="est-terms__pct stamp">25%</div>
                <div className="est-terms__main">
                  <div className="est-terms__title">Final on completion</div>
                  <div className="est-terms__meta">After punch-list sign-off</div>
                </div>
                <div className="est-terms__amt stamp">${Math.round(grand * 0.25).toLocaleString()}</div>
              </div>
            </section>
          </>
        )}

        <div className="bot-spacer"></div>
      </div>

      {/* Bottom CTA bar — primary action depends on view */}
      <div className="cta-bar">
        {view === 'build' ? (
          <>
            <button className="cta-bar__secondary" onClick={() => setView('preview')}>
              Preview
            </button>
            <button className="cta-bar__primary">
              Save draft
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
            </button>
          </>
        ) : (
          <>
            <button className="cta-bar__secondary" aria-label="Download PDF">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
            </button>
            <button className="cta-bar__primary">
              Send to client
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4z"/></svg>
            </button>
          </>
        )}
      </div>
    </div>
  );
};
