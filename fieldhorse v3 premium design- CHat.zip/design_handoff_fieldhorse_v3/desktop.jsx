/* global React */

window.DesktopHome = function DesktopHome() {
  return (
    <div className="desktop-frame">
      <DesktopSidebar active="home" />
      <div className="dt-main">
        <div className="dt-topbar">
          <div className="dt-topbar__crumb">PARKER · <b>Dashboard</b></div>
          <div className="dt-topbar__actions">
            <div className="dt-search">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
              <span>Search jobs, clients, invoices…</span>
              <span style={{ marginLeft: 'auto', fontSize: 10, padding: '2px 6px', border: '1px solid var(--hair)', borderRadius: 4, color: 'var(--ink-3)' }}>⌘K</span>
            </div>
            <button className="icon-btn icon-btn--dot">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
              <span className="icon-btn__dot"></span>
            </button>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg, #3a2a18, #1a1208)', border: '1px solid var(--hair-gold)', display: 'grid', placeItems: 'center', fontFamily: 'var(--f-stamp)', fontSize: 12, color: 'var(--gold-bright)', letterSpacing: '0.06em' }}>JP</div>
          </div>
        </div>

        <div className="dt-content">
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 8 }}>Tuesday · April 28</div>
              <h1 className="dt-h1">Good morning, <em className="gold-italic">Jesse.</em></h1>
              <p className="dt-h1__sub">Three crews on site. All green. <b style={{ color: 'var(--ink-2)' }}>$24,300</b> invoicing this week.</p>
            </div>
            <div className="weather" style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minWidth: 0 }}>
              <div className="weather__temp stamp">71°</div>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--ink)' }}>Partly cloudy</div>
                <div style={{ fontSize: 10, color: 'var(--ink-3)', letterSpacing: '0.08em', marginTop: 2 }}>WIND 5 MPH · MURFREESBORO</div>
              </div>
            </div>
          </div>

          <div className="dt-grid">
            {/* Pipeline hero */}
            <div className="dt-card dt-card--hero" style={{ padding: 28 }}>
              <div className="pipeline-hero__head" style={{ marginBottom: 12 }}>
                <div className="eyebrow">Today's revenue opportunity</div>
                <span className="trend">
                  <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m5 12 7-7 7 7"/><path d="M12 19V5"/></svg>
                  +6% vs last 7d
                </span>
              </div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginBottom: 6 }}>
                <div className="pipeline-hero__amt" style={{ fontSize: 64, margin: 0 }}>
                  <span className="stamp">$136,000</span>
                </div>
                <div style={{ color: 'var(--ink-3)', fontSize: 12 }}>Total pipeline</div>
              </div>
              <svg className="spark" viewBox="0 0 800 80" preserveAspectRatio="none" style={{ height: 80, marginTop: 14 }}>
                <defs>
                  <linearGradient id="dt-spark" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#E4BE6F" stopOpacity="0.32"/>
                    <stop offset="100%" stopColor="#E4BE6F" stopOpacity="0"/>
                  </linearGradient>
                </defs>
                <path d="M0,62 L60,56 L120,52 L180,42 L240,46 L300,38 L360,42 L420,30 L480,36 L540,24 L600,28 L660,16 L720,10 L800,6 L800,80 L0,80 Z" fill="url(#dt-spark)"/>
                <path d="M0,62 L60,56 L120,52 L180,42 L240,46 L300,38 L360,42 L420,30 L480,36 L540,24 L600,28 L660,16 L720,10 L800,6" fill="none" stroke="#E4BE6F" strokeWidth="1.6"/>
              </svg>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0, borderTop: '1px solid var(--hair)', paddingTop: 18, marginTop: 18 }}>
                {[
                  { n: 3, l: 'Won', c: 'var(--won)', amt: '$42K' },
                  { n: 4, l: 'Active', c: 'var(--active)', amt: '$56K' },
                  { n: 4, l: 'Lead', c: 'var(--lead)', amt: '$38K' },
                ].map((b, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, paddingLeft: i === 0 ? 0 : 18, borderLeft: i === 0 ? 'none' : '1px solid var(--hair)' }}>
                    <span style={{ width: 8, height: 8, borderRadius: '50%', background: b.c, boxShadow: `0 0 8px ${b.c}` }}></span>
                    <div>
                      <div style={{ fontSize: 22, lineHeight: 1, color: 'var(--ink)' }} className="stamp">{b.n}</div>
                      <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.18em', color: 'var(--ink-3)', marginTop: 4 }}>{b.l.toUpperCase()} · <span className="stamp" style={{ letterSpacing: 0.5 }}>{b.amt}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Today's priorities */}
            <div className="dt-card">
              <div className="block__head" style={{ marginBottom: 14 }}>
                <div className="eyebrow">Today's priorities</div>
                <button className="link">View all</button>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div className="prio__cell prio__cell--alert" style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 14px' }}>
                  <div className="stamp" style={{ fontSize: 28, color: 'var(--alert)' }}>2</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--ink)' }}>Follow-ups</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>Leads gone cold</div>
                  </div>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" strokeWidth="1.7" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
                </div>
                <div className="prio__cell prio__cell--warn" style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 14px' }}>
                  <div className="stamp" style={{ fontSize: 28, color: 'var(--warn)' }}>2</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--ink)' }}>Quotes</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>Need attention</div>
                  </div>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" strokeWidth="1.7" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
                </div>
                <div className="prio__cell" style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 14px' }}>
                  <div className="stamp" style={{ fontSize: 24, color: 'var(--gold-bright)' }}>$24.3K</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--ink)' }}>Invoicing</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>This week</div>
                  </div>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" strokeWidth="1.7" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
                </div>
              </div>
            </div>
          </div>

          <div className="dt-grid" style={{ gridTemplateColumns: '2fr 1fr' }}>
            {/* Today on site */}
            <div className="dt-card">
              <div className="block__head" style={{ marginBottom: 14 }}>
                <div className="eyebrow">Today on site</div>
                <button className="link">View schedule →</button>
              </div>
              <div className="site-list">
                {[
                  { t: '8:15', a: 'AM', n: 'MMC Properties', m: 'Crew arrived · Summer Creek rail painting', s: 'On site', g: 'good', c: 'var(--good)' },
                  { t: '10:30', a: 'AM', n: 'Matthew Addition', m: 'Material delivery · bathroom addition', s: 'Upcoming', c: 'var(--gold)' },
                  { t: '2:00', a: 'PM', n: 'Jeff Roy', m: 'Roof inspection · walkthrough with client', s: 'Upcoming', c: 'var(--lead)' },
                  { t: '4:30', a: 'PM', n: 'Lily Grace North', m: 'Site walk with client · concrete restoration', s: 'In progress', c: 'var(--active)' },
                ].map((r, i) => (
                  <div key={i} className="site-row">
                    <div className="site-row__time">
                      <div className="site-row__hr stamp">{r.t}</div>
                      <div className="site-row__ap">{r.a}</div>
                    </div>
                    <div className="site-row__rule" style={{ background: r.c }}></div>
                    <div className="site-row__main">
                      <div className="site-row__name">{r.n}</div>
                      <div className="site-row__meta">{r.m}</div>
                    </div>
                    <span className={`pill ${r.g === 'good' ? 'pill--good' : ''}`}>{r.s}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Pipeline preview */}
            <div className="dt-card">
              <div className="block__head" style={{ marginBottom: 14 }}>
                <div className="eyebrow">Pipeline preview</div>
                <button className="link">View all →</button>
              </div>
              <div className="pipe-list">
                {[
                  { c: 'MMC Properties', s: 'QUOTE · 2/5', a: '$49K', col: 'var(--quote)' },
                  { c: 'Jeff Roy', s: 'QUOTE · 2/5', a: '$24K', col: 'var(--quote)' },
                  { c: 'Lily Grace North', s: 'LEAD · 1/5', a: '$17K', col: 'var(--lead)' },
                  { c: 'Heather Neighbor', s: 'LEAD · 1/5', a: '$0', col: 'var(--lead)' },
                ].map((p, i) => (
                  <button key={i} className="pipe-row">
                    <div className="pipe-row__rule" style={{ background: p.col }}></div>
                    <div className="pipe-row__main">
                      <div className="pipe-row__client">{p.c}</div>
                      <div className="pipe-row__sub">{p.s}</div>
                    </div>
                    <div className="pipe-row__amt">
                      <span className="stamp">{p.a}</span>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="m9 18 6-6-6-6"/></svg>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

window.DesktopJobs = function DesktopJobs() {
  const photos = [
    { from: '#4a3522', to: '#1c1208', accent: '#6b5530' },
    { from: '#3a2820', to: '#180f08', accent: '#5a3e2a' },
    { from: '#3d3022', to: '#1a1408', accent: '#6b5535' },
    { from: '#2a2415', to: '#100c06', accent: '#4a4025' },
    { from: '#332218', to: '#150d08', accent: '#553a26' },
  ];
  const renderPhoto = (i) => {
    const p = photos[i % photos.length];
    return (
      <svg viewBox="0 0 200 100" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id={`dtg-${i}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={p.from}/>
            <stop offset="100%" stopColor={p.to}/>
          </linearGradient>
        </defs>
        <rect width="200" height="100" fill={`url(#dtg-${i})`}/>
        <polygon points="0,68 60,40 110,52 200,30 200,100 0,100" fill={p.accent} opacity="0.4"/>
        <polygon points="0,80 50,62 100,72 200,52 200,100 0,100" fill={p.to} opacity="0.7"/>
      </svg>
    );
  };

  return (
    <div className="desktop-frame">
      <DesktopSidebar active="jobs" />
      <div className="dt-main">
        <div className="dt-topbar">
          <div className="dt-topbar__crumb">PARKER · <b>Jobs &amp; Pipeline</b></div>
          <div className="dt-topbar__actions">
            <div className="dt-search">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
              <span>Search jobs…</span>
            </div>
            <button style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '8px 14px', borderRadius: 8, background: 'var(--gold)', color: '#1a130a', fontSize: 12, fontWeight: 600, border: 'none', cursor: 'pointer', boxShadow: '0 6px 14px rgba(201,150,58,0.35)' }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>
              New Job
            </button>
          </div>
        </div>

        <div className="dt-content">
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
            <div>
              <h1 className="dt-h1">Jobs <em className="gold-italic">&amp; Pipeline</em></h1>
              <p className="dt-h1__sub"><b className="stamp" style={{ color: 'var(--gold-bright)', fontSize: 16 }}>11</b> total · <b className="stamp" style={{ color: 'var(--ink)', fontSize: 16 }}>$236K</b> in motion · 3 need eyes today</p>
            </div>
          </div>

          <div className="filt-row" style={{ padding: '20px 0 0', overflowX: 'visible' }}>
            <button className="filt filt--on">All <span className="filt__c">11</span></button>
            <button className="filt">Lead <span className="filt__c">2</span></button>
            <button className="filt">Quote <span className="filt__c">2</span></button>
            <button className="filt">Active <span className="filt__c">6</span></button>
            <button className="filt">Won <span className="filt__c">1</span></button>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
              <button className="filt">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M22 3H2l8 9.5V21l4-2v-6.5z"/></svg>
                Filter
              </button>
              <button className="filt">Sort: Recency</button>
            </div>
          </div>

          {/* Jobs grid */}
          <div className="dt-jobs-grid">
            {/* Featured */}
            <div className="dt-job dt-job--feature" style={{ borderColor: 'var(--hair-gold)', boxShadow: 'var(--lift-2)' }}>
              <div className="dt-job__photo" style={{ position: 'relative' }}>
                {renderPhoto(0)}
                <div style={{ position: 'absolute', top: 12, left: 12, display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 9px', background: 'var(--gold)', color: '#1a130a', fontSize: 9, fontWeight: 700, letterSpacing: '0.14em', borderRadius: 4 }}>
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 16.8l-6.2 4.5 2.4-7.4L2 9.4h7.6z"/></svg>
                  TOP DEAL
                </div>
              </div>
              <div className="dt-job__body" style={{ padding: '16px 18px 18px' }}>
                <div className="dt-job__client">MMC PROPERTIES</div>
                <div className="dt-job__name" style={{ fontSize: 18 }}>Summer Creek Roll Painting</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10, padding: '8px 10px', background: 'var(--surface-2)', borderRadius: 8, border: '1px solid var(--hair)', fontSize: 11, color: 'var(--ink-2)' }}>
                  <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--gold-bright)', boxShadow: '0 0 6px var(--gold-glow)' }}></span>
                  <span><b style={{ color: 'var(--ink)' }}>Next:</b> Get approval signed</span>
                </div>
                <div className="dt-job__row" style={{ marginTop: 14 }}>
                  <div>
                    <span className="stamp" style={{ fontSize: 28, color: 'var(--ink)' }}>$46,000</span>
                    <div className="dt-job__margin"><span className="stamp">38%</span> margin</div>
                  </div>
                </div>
                <div className="dt-job__foot" style={{ marginTop: 14 }}>
                  <span className="stage-pill stage-pill--quote">QUOTE</span>
                  <div className="stage-bar">
                    <div className="stage-bar__seg is-on is-on--quote"></div>
                    <div className="stage-bar__seg is-on is-on--quote"></div>
                    <div className="stage-bar__seg"></div>
                    <div className="stage-bar__seg"></div>
                    <div className="stage-bar__seg"></div>
                  </div>
                  <span className="stage-step">2/5</span>
                </div>
              </div>
            </div>

            {/* Standard cards */}
            {[
              { c: 'MATTHEW ADDITION', n: 'Bathroom addition', a: '$30,000', m: '28%', s: 'active', step: 3, next: 'Schedule final walkthrough' },
              { c: 'MMC PROPERTIES', n: 'Summer Creek rail', a: '$13,000', m: '32%', s: 'active', step: 3, next: 'Material delivery 10:30 AM' },
              { c: 'JEFF ROY', n: 'Roof · Deck · Chimney', a: '$24,400', m: '24%', s: 'quote', step: 2, next: 'Get approval signed' },
              { c: 'LILY GRACE NORTH', n: 'Concrete restoration', a: '$18,600', m: '30%', s: 'lead', step: 1, next: 'Send a quote' },
              { c: 'HEATHER NEIGHBOR', n: 'Plumbing issue', a: '$0', m: '—', s: 'lead', step: 1, next: 'Send a quote' },
              { c: 'P2 - DEENA NOLAN', n: 'Contents Manage', a: '$2,250', m: '—', s: 'active', step: 3, next: 'Job in progress' },
              { c: 'JUSTIN HOUSE', n: 'Windows + Concrete', a: '$2,000', m: '—', s: 'active', step: 3, next: 'Job in progress' },
              { c: 'ST ANDREWS APT', n: 'Paint Compactor', a: '$500', m: '—', s: 'active', step: 3, next: 'Job in progress' },
              { c: 'VINTAGE BURKITT', n: 'Handrails · Paint', a: '$13,000', m: '—', s: 'active', step: 3, next: 'Job in progress' },
            ].map((j, i) => {
              const stageMeta = {
                lead:   'stage-pill--lead',
                quote:  'stage-pill--quote',
                active: 'stage-pill--active',
                won:    'stage-pill--won',
              }[j.s];
              return (
                <div key={i} className="dt-job">
                  <div className="dt-job__photo">{renderPhoto(i + 1)}</div>
                  <div className="dt-job__body">
                    <div className="dt-job__client">{j.c}</div>
                    <div className="dt-job__name">{j.n}</div>
                    <div className="dt-job__row">
                      <span className="stamp" style={{ fontSize: 18, color: 'var(--ink)' }}>{j.a}</span>
                      <span className="dt-job__margin"><span className="stamp">{j.m}</span> margin</span>
                    </div>
                    <div className="dt-job__foot">
                      <span className={`stage-pill ${stageMeta}`}>{j.s.toUpperCase()}</span>
                      <div className="stage-bar">
                        {[1,2,3,4,5].map(k => (
                          <div key={k} className={`stage-bar__seg ${k <= j.step ? `is-on is-on--${j.s}` : ''}`}></div>
                        ))}
                      </div>
                      <span className="stage-step">{j.step}/5</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

window.DesktopSidebar = function DesktopSidebar({ active }) {
  const items = [
    { id: 'home', label: 'Dashboard', icon: <path d="M3 11 12 3l9 8M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"/> },
    { id: 'jobs', label: 'Jobs & Pipeline', icon: <><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/></>, count: 11 },
    { id: 'clients', label: 'Clients', icon: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>, count: 14 },
    { id: 'schedule', label: 'Schedule', icon: <><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></> },
    { id: 'estimates', label: 'Estimates', icon: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h4"/></> },
    { id: 'invoices', label: 'Invoices & Payments', icon: <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>, count: 5 },
    { id: 'reports', label: 'Reports & Insights', icon: <><path d="M3 3v18h18"/><path d="m7 14 4-4 4 4 5-5"/></> },
  ];
  return (
    <div className="dt-side">
      <div className="dt-side__brand">
        <div className="dt-side__fh">FH</div>
        <div>
          <div className="dt-side__co">PARKER</div>
          <div className="dt-side__tag">Construction Co.</div>
        </div>
      </div>
      <div className="dt-nav">
        <div className="dt-nav__sec">Workspace</div>
        {items.map(it => (
          <button key={it.id} className={`dt-nav__item ${active === it.id ? 'is-on' : ''}`}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">{it.icon}</svg>
            <span>{it.label}</span>
            {it.count && <span className="dt-nav__count">{it.count}</span>}
          </button>
        ))}
        <div className="dt-nav__sec">Account</div>
        <button className="dt-nav__item">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
          <span>Settings</span>
        </button>
        <button className="dt-nav__item">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>
          <span>Help & Support</span>
        </button>
      </div>
      <div style={{ marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 10, padding: '12px 10px', borderTop: '1px solid var(--hair)', marginInline: -8 }}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg, #3a2a18, #1a1208)', border: '1px solid var(--hair-gold)', display: 'grid', placeItems: 'center', fontFamily: 'var(--f-stamp)', fontSize: 12, color: 'var(--gold-bright)' }}>JP</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink)' }}>Jesse Parker</div>
          <div style={{ fontSize: 10, color: 'var(--ink-3)' }}>Account Settings</div>
        </div>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ink-3)" strokeWidth="1.7"><path d="m9 18 6-6-6-6"/></svg>
      </div>
    </div>
  );
};
