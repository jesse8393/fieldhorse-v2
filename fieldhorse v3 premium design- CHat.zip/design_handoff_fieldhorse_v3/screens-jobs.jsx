/* global React */
const { useState } = React;

window.JobsScreen = function JobsScreen() {
  const [filter, setFilter] = useState('all');

  const filters = [
    { id: 'all', label: 'All', count: 11 },
    { id: 'lead', label: 'Lead', count: 2 },
    { id: 'quote', label: 'Quote', count: 2 },
    { id: 'active', label: 'Active', count: 6 },
    { id: 'won', label: 'Won', count: 1 },
  ];

  return (
    <div className="screen">
      {/* Header */}
      <div className="app-head app-head--titled">
        <div className="app-head__title-block">
          <h1 className="jobs-title">Jobs <span style={{ color: 'var(--gold-bright)' }}>&amp; Pipeline</span></h1>
          <div className="jobs-stats">
            <span><b className="stamp">11</b> total</span>
            <span className="dot-sep">·</span>
            <span><b className="stamp">$236K</b> in motion</span>
            <span className="dot-sep">·</span>
            <span className="jobs-stats__alert"><b className="stamp">3</b> need eyes</span>
          </div>
        </div>
        <div className="app-head__actions">
          <button className="icon-btn" aria-label="Sort">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M11 5h10M11 9h7M11 13h4M3 17l3 3 3-3M6 20V4"/></svg>
          </button>
          <button className="icon-btn" aria-label="Filter">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M22 3H2l8 9.5V21l4-2v-6.5z"/></svg>
          </button>
        </div>
      </div>

      <div className="screen__body no-scroll">

        {/* Search */}
        <div className="jobs-search">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
          <span>Search jobs, contacts, addresses…</span>
          <span className="jobs-search__kbd">⌘K</span>
        </div>

        {/* Filter pills */}
        <div className="filt-row no-scroll">
          {filters.map(f => (
            <button
              key={f.id}
              className={`filt ${filter === f.id ? 'filt--on' : ''}`}
              onClick={() => setFilter(f.id)}
            >
              {f.label}
              <span className="filt__c">{f.count}</span>
            </button>
          ))}
        </div>

        {/* Featured high-value job — refined premium */}
        <div className="job-feature">
          <div className="job-feature__photo">
            <svg viewBox="0 0 320 200" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
              <defs>
                <linearGradient id="ph1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#5a4530"/>
                  <stop offset="55%" stopColor="#2a1f15"/>
                  <stop offset="100%" stopColor="#0a0805"/>
                </linearGradient>
                <linearGradient id="ph1-vig" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#000" stopOpacity="0.05"/>
                  <stop offset="60%" stopColor="#000" stopOpacity="0.1"/>
                  <stop offset="100%" stopColor="#000" stopOpacity="0.7"/>
                </linearGradient>
              </defs>
              <rect width="320" height="200" fill="url(#ph1)"/>
              {/* horizon */}
              <polygon points="0,140 320,120 320,200 0,200" fill="#0e0a07" opacity="0.7"/>
              {/* main building */}
              <rect x="60" y="60" width="120" height="100" fill="#1a130c" stroke="#3a2c1a" strokeWidth="0.5"/>
              <rect x="68" y="72" width="20" height="24" fill="#7a5e30" opacity="0.6"/>
              <rect x="92" y="72" width="20" height="24" fill="#5a4520" opacity="0.5"/>
              <rect x="116" y="72" width="20" height="24" fill="#7a5e30" opacity="0.6"/>
              <rect x="140" y="72" width="20" height="24" fill="#5a4520" opacity="0.5"/>
              <rect x="68" y="104" width="20" height="24" fill="#3a2c1a"/>
              <rect x="92" y="104" width="20" height="24" fill="#3a2c1a"/>
              <rect x="116" y="104" width="20" height="24" fill="#3a2c1a"/>
              <rect x="140" y="104" width="20" height="24" fill="#3a2c1a"/>
              {/* annex */}
              <rect x="200" y="90" width="80" height="70" fill="#1f1810" stroke="#3a2c1a" strokeWidth="0.5"/>
              <rect x="210" y="100" width="14" height="18" fill="#6b5530" opacity="0.55"/>
              <rect x="232" y="100" width="14" height="18" fill="#6b5530" opacity="0.55"/>
              <rect x="254" y="100" width="14" height="18" fill="#6b5530" opacity="0.55"/>
              {/* vignette */}
              <rect width="320" height="200" fill="url(#ph1-vig)"/>
            </svg>
            <div className="job-feature__overlay">
              <span className="job-feature__badge">
                <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 16.8l-6.2 4.5 2.4-7.4L2 9.4h7.6z"/></svg>
                TOP DEAL
              </span>
              <div className="job-feature__photo-meta">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/></svg>
                <span>4 photos</span>
              </div>
            </div>
            {/* Floating amount tag */}
            <div className="job-feature__amt-float">
              <div className="stamp">$46,000</div>
              <div className="job-feature__margin-float">
                <span className="stamp">38%</span>
                <span>margin · <b>$17.5K profit</b></span>
              </div>
            </div>
          </div>

          <div className="job-feature__body">
            <div className="job-feature__title-block">
              <div className="job-feature__client">MMC PROPERTIES · COMMERCIAL</div>
              <div className="job-feature__name">Summer Creek roll painting</div>
            </div>

            <div className="job-feature__action">
              <span className="job-feature__action-dot"></span>
              <div className="job-feature__action-text">
                <div className="job-feature__action-label">Next action</div>
                <div className="job-feature__action-body">Get approval signed by <b>Apr 30</b></div>
              </div>
              <button className="job-feature__action-cta">Mark Done</button>
            </div>

            <div className="job-feature__foot">
              <div className="job-feature__stage">
                <span className="stage-pill stage-pill--quote">QUOTE</span>
                <div className="stage-bar">
                  <div className="stage-bar__seg is-on is-on--quote"></div>
                  <div className="stage-bar__seg is-on is-on--quote"></div>
                  <div className="stage-bar__seg"></div>
                  <div className="stage-bar__seg"></div>
                  <div className="stage-bar__seg"></div>
                </div>
                <span className="stage-step">2/5</span>
              </div>
            </div>
          </div>
        </div>

        {/* Section divider */}
        <div className="job-divider">
          <span className="job-divider__line"></span>
          <span className="job-divider__lbl">All jobs · sorted by activity</span>
          <span className="job-divider__line"></span>
        </div>

        {/* Job cards */}
        <div className="job-list">

          <JobCard
            initials="MA"
            client="Matthew Addition"
            jobName="Bathroom addition"
            location="Downtown · 2.4 mi"
            amount="$30,000"
            margin="28%"
            stage="active"
            stageStep={3}
            nextAction="Schedule final walkthrough"
            actionDue="today"
            statusFlag="onsite"
            photoVariant="a"
          />

          <JobCard
            initials="MMC"
            client="MMC Properties"
            jobName="Summer Creek rail painting"
            location="Summer Creek · 8.1 mi"
            amount="$13,000"
            margin="32%"
            stage="active"
            stageStep={3}
            nextAction="Material delivery 10:30 AM"
            actionDue="49m"
            statusFlag="onsite"
            photoVariant="b"
          />

          <JobCard
            initials="JR"
            client="Jeff Roy"
            jobName="Roof · deck · chimney"
            location="Westwood · 5.2 mi"
            amount="$24,400"
            margin="24%"
            stage="quote"
            stageStep={2}
            nextAction="Get approval signed"
            actionDue="2d"
            statusFlag={null}
            photoVariant="c"
          />

          <JobCard
            initials="LG"
            client="Lily Grace North"
            jobName="Concrete restoration"
            location="Belle Meade · 11 mi"
            amount="$18,600"
            margin="30%"
            stage="lead"
            stageStep={1}
            nextAction="Send a quote"
            actionDue="cold 4d"
            statusFlag="cold"
            photoVariant="d"
          />

          <JobCard
            initials="HN"
            client="Heather Neighbor"
            jobName="Plumbing issue"
            location="East side · 6 mi"
            amount={null}
            margin={null}
            stage="lead"
            stageStep={1}
            nextAction="First call"
            actionDue="cold 8d"
            statusFlag="cold"
            photoVariant="e"
          />

          <JobCard
            initials="SC"
            client="Summer Creek"
            jobName="Concrete remodel"
            location="Summer Creek · 8.1 mi"
            amount="$14,800"
            margin="—"
            stage="closed"
            stageStep={5}
            nextAction={null}
            actionDue={null}
            statusFlag="won"
            photoVariant="f"
          />

        </div>

        <div className="bot-spacer"></div>
      </div>

      {/* FAB */}
      <button className="fab" aria-label="New job">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>
      </button>

      <BottomNav active="jobs" />
    </div>
  );
};

window.JobCard = function JobCard({ initials, client, jobName, location, amount, margin, stage, stageStep, nextAction, actionDue, statusFlag, photoVariant }) {
  const photos = {
    a: { from: '#4a3522', to: '#1c1208', accent: '#6b5530' },
    b: { from: '#3a2820', to: '#180f08', accent: '#5a3e2a' },
    c: { from: '#3d3022', to: '#1a1408', accent: '#6b5535' },
    d: { from: '#2a2415', to: '#100c06', accent: '#4a4025' },
    e: { from: '#332218', to: '#150d08', accent: '#553a26' },
    f: { from: '#1f1a14', to: '#0c0805', accent: '#3a2f22' },
  };
  const p = photos[photoVariant] || photos.a;

  const stageMeta = {
    lead:   { label: 'LEAD',   className: 'stage-pill--lead' },
    quote:  { label: 'QUOTE',  className: 'stage-pill--quote' },
    active: { label: 'ACTIVE', className: 'stage-pill--active' },
    won:    { label: 'WON',    className: 'stage-pill--won' },
    closed: { label: 'CLOSED', className: 'stage-pill--closed' },
  }[stage];

  const flagMap = {
    onsite: { label: 'ON SITE', cls: 'jc-flag--good', dot: 'var(--good)' },
    cold:   { label: 'COLD',    cls: 'jc-flag--alert', dot: 'var(--alert)' },
    won:    { label: 'WON',     cls: 'jc-flag--gold', dot: 'var(--gold-bright)' },
  };
  const flag = statusFlag ? flagMap[statusFlag] : null;

  return (
    <button className="job-card">
      {/* PHOTO TILE */}
      <div className="job-card__photo">
        <svg viewBox="0 0 80 100" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id={`g-${photoVariant}`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor={p.from}/>
              <stop offset="100%" stopColor={p.to}/>
            </linearGradient>
          </defs>
          <rect width="80" height="100" fill={`url(#g-${photoVariant})`}/>
          <polygon points="0,68 30,40 55,52 80,32 80,100 0,100" fill={p.accent} opacity="0.4"/>
          <polygon points="0,80 25,62 50,72 80,52 80,100 0,100" fill={p.to} opacity="0.7"/>
        </svg>
        <div className="job-card__initials-tag">
          <span>{initials}</span>
        </div>
        {flag && (
          <div className={`jc-flag ${flag.cls}`}>
            <span className="jc-flag__dot" style={{ background: flag.dot }}></span>
            {flag.label}
          </div>
        )}
      </div>

      {/* BODY */}
      <div className="job-card__body">
        <div className="job-card__top">
          <div className="job-card__title-block">
            <div className="job-card__client">{client}</div>
            <div className="job-card__name">{jobName}</div>
            <div className="job-card__loc">
              <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              {location}
            </div>
          </div>
          <div className="job-card__amt-block">
            {amount ? (
              <>
                <div className="job-card__amt stamp">{amount}</div>
                {margin && margin !== '—' && (
                  <div className="job-card__margin">
                    <span className="stamp">{margin}</span> margin
                  </div>
                )}
                {margin === '—' && (
                  <div className="job-card__margin job-card__margin--mute">— margin</div>
                )}
              </>
            ) : (
              <div className="job-card__amt-empty">—</div>
            )}
          </div>
        </div>

        {nextAction && (
          <div className="job-card__action">
            <span className="job-card__action-bullet"></span>
            <span className="job-card__action-text"><b>Next:</b> {nextAction}</span>
            {actionDue && <span className="job-card__action-due">{actionDue}</span>}
          </div>
        )}

        <div className="job-card__foot">
          <span className={`stage-pill ${stageMeta.className}`}>{stageMeta.label}</span>
          <div className="stage-bar">
            {[1,2,3,4,5].map(i => (
              <div key={i} className={`stage-bar__seg ${i <= stageStep ? `is-on is-on--${stage}` : ''}`}></div>
            ))}
          </div>
          <span className="stage-step">{stageStep}/5</span>
        </div>
      </div>
    </button>
  );
};
