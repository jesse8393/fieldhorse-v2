# Handoff: Fieldhorse v3 — Premium Construction OS

## Overview

Fieldhorse is a premium operating system for high-revenue residential construction companies. This design package covers the complete mobile + desktop UI for an owner-operator (Jesse Parker, Parker Construction Co., Murfreesboro TN). The product helps builders manage jobs, clients, estimates, invoices, scheduling, notes, and AI-assisted communication — all from a single dark, warm-gold interface.

## About the Design Files

The files in this bundle are **design references created in HTML/React** — hi-fi prototypes showing intended look and behavior. They are NOT production code. The task is to **recreate these designs** in the target codebase's environment (likely React/Next.js or React Native for mobile) using its established patterns and component libraries.

The main canvas file (`Fieldhorse v3.html`) uses a pan/zoom design canvas to present all screens side by side. Each screen is a self-contained React component.

## Fidelity

**High-fidelity (hifi).** These are pixel-perfect mockups with final colors, typography, spacing, interactions, and component states. Recreate the UI faithfully using the codebase's existing libraries and patterns. Every hex color, font size, spacing value, and border radius is intentional.

## Implementation Status

Each screen has a status badge in the design:

| Status | Meaning |
|--------|---------|
| 🟢 **Ready · Implement** | Approved for implementation as-is |
| 🟡 **Polish later** | Direction is correct; details may shift |

### Mobile Screens

| # | Screen | Component | File | Status |
|---|--------|-----------|------|--------|
| 01 | Home / Daily brief | `HomeScreen` | `screens-home.jsx` | 🟢 Ready |
| 02 | Jobs & Pipeline | `JobsScreen` | `screens-jobs.jsx` | 🟢 Ready |
| 03 | Schedule | `ScheduleScreen` | `screens-schedule-estimate.jsx` | 🟡 Polish |
| 04 | Job Detail | `JobDetailRealScreen` | `screens-detail-est-owed.jsx` | 🟢 Ready |
| 05 | Estimate Builder + Preview | `EstimateScreen` | `screens-schedule-estimate.jsx` | 🟡 Polish |
| 06 | Clients | `ClientsScreen` | `screens-workflows.jsx` | 🟢 Ready |
| 07 | Money Owed | `OwedScreen` | `screens-detail-est-owed.jsx` | 🟢 Ready |
| 08 | New Lead Capture | `NewLeadScreen` | `screens-workflows.jsx` | 🟡 Polish |
| 09 | Notes & Capture | `NotesScreen` | `screens-workflows.jsx` | 🟡 Polish |
| 10 | AI Compose | `ComposeScreen` | `screens-compose-nav.jsx` | 🟢 Ready |
| 11 | Nav Menu | `NavScreen` | `screens-compose-nav.jsx` | 🟢 Ready |

### Desktop Screens

| # | Screen | Component | File | Status |
|---|--------|-----------|------|--------|
| 01 | Home Dashboard | `DesktopHome` | `desktop.jsx` | 🟢 Ready |
| 02 | Jobs & Pipeline | `DesktopJobs` | `desktop.jsx` | 🟢 Ready |
| 03 | Job Detail Cockpit | `DesktopJobDetail` | `desktop-flows-1.jsx` | 🟢 Ready |
| 04 | Clients | `DesktopClients` | `desktop-flows-1.jsx` | 🟢 Ready |
| 05 | Money Owed | `DesktopOwed` | `desktop-flows-2.jsx` | 🟢 Ready |
| 06 | Estimate Builder + Preview | `DesktopEstimate` | `desktop-flows-2.jsx` | 🟢 Ready |
| 07 | AI Compose | `DesktopCompose` | `desktop-flows-2.jsx` | 🟢 Ready |

### Shared Components

| Component | File | Notes |
|-----------|------|-------|
| `DesktopSidebar` | `desktop.jsx` | Shared sidebar nav for all desktop views |
| `DTopbar` | `desktop-flows-1.jsx` | Shared top bar with breadcrumbs, search, avatar |
| `BottomNav` | `screens-home.jsx` | Mobile bottom tab bar |
| `AppHeader` | `screens-home.jsx` | Mobile app header |
| `PhoneFrame` | `app.jsx` | Design-only device bezel (do not implement) |

---

## Design Tokens

All tokens are defined in `tokens.css`. Here is the complete set:

### Surfaces (warm onyx — never blue, never neutral gray)

| Token | Value | Usage |
|-------|-------|-------|
| `--bg` | `#0B0907` | Page background — deepest warm black |
| `--surface-1` | `#141110` | Card background |
| `--surface-2` | `#1C1814` | Raised card / inner surfaces |
| `--surface-3` | `#252019` | Hover / pressed inner |
| `--surface-glass` | `rgba(28, 24, 20, 0.72)` | Glass overlay |

### Hairlines (borders)

| Token | Value | Usage |
|-------|-------|-------|
| `--hair` | `rgba(255, 240, 210, 0.06)` | Default border |
| `--hair-2` | `rgba(255, 240, 210, 0.10)` | Slightly stronger |
| `--hair-strong` | `rgba(255, 240, 210, 0.18)` | Emphasis border |
| `--hair-gold` | `rgba(201, 150, 58, 0.28)` | Gold-tinted border |

### Text

| Token | Value | Usage |
|-------|-------|-------|
| `--ink` | `#F2EDE4` | Primary text |
| `--ink-2` | `rgba(242, 237, 228, 0.78)` | Secondary text |
| `--ink-3` | `rgba(242, 237, 228, 0.55)` | Tertiary / labels |
| `--ink-4` | `rgba(242, 237, 228, 0.38)` | Disabled / hint |

### Brand Gold

| Token | Value | Usage |
|-------|-------|-------|
| `--gold` | `#C9963A` | Primary gold |
| `--gold-hot` | `#E4BE6F` | Warm highlight |
| `--gold-bright` | `#E8B865` | Bright accent — CTAs, active state, eyebrows |
| `--gold-deep` | `#8C6F30` | Dark gold — borders, CTA borders |
| `--gold-soft` | `rgba(201, 150, 58, 0.14)` | Gold tint background |
| `--gold-glow` | `rgba(228, 190, 111, 0.22)` | Glow effect |

### Pipeline Stage Colors

| Token | Value | Usage |
|-------|-------|-------|
| `--lead` | `#6B7CA8` | Lead stage — steel blue |
| `--quote` | `#B07A4A` | Quote stage — burnished bronze |
| `--active` | `#4F8C5E` | Active stage — moss green |
| `--won` | `#C9963A` | Won stage — gold |
| `--closed` | `#5C5C5C` | Closed — steel gray |

### Semantic Colors

| Token | Value | Usage |
|-------|-------|-------|
| `--alert` | `#C0392B` | Error / danger |
| `--alert-soft` | `rgba(192, 57, 43, 0.16)` | Alert background |
| `--warn` | `#D4A042` | Warning |
| `--good` | `#4F8C5E` | Success / on-track |
| `--good-soft` | `rgba(79, 140, 94, 0.16)` | Good background |

### Typography

Three type voices:

| Family | Variable | Usage |
|--------|----------|-------|
| **DM Sans** (400/500/600/700) | `--f-ui` | All body text, labels, UI |
| **Instrument Serif** (italic) | `--f-serif` | Gold-italic hero accent — ONLY on H1 display titles |
| **Bebas Neue** (400) | `--f-stamp` | All numbers, amounts, timestamps, KPI values |

Type scale (mobile):

| Role | Size | Weight | Tracking | Notes |
|------|------|--------|----------|-------|
| Display | 56–60px | 600 | -0.025em | DM Sans + gold-italic serif accent |
| H1 / page title | 28–32px | 600 | -0.025em | DM Sans |
| Section label | 10px | 700 | 0.18em | Uppercase, `--ink-3` |
| Eyebrow | 10px | 600 | 0.18em | Uppercase, gold or muted |
| Body | 13–14px | 400 | 0 | DM Sans |
| Stamp (numbers) | varies | 400 | 0.005em | Bebas Neue, tabular-nums |

### Spacing & Radius

| Token | Value |
|-------|-------|
| `--r-xs` | 6px |
| `--r-sm` | 10px |
| `--r-md` | 14px |
| `--r-lg` | 18px |
| `--r-xl` | 24px |

Standard mobile padding: `16px` horizontal. Card padding: `14–16px`. Section gap: `18px top, 10px bottom`.

### Shadows

| Token | Value | Usage |
|-------|-------|-------|
| `--lift-1` | `0 1px 0 rgba(255,240,210,0.04) inset, 0 4px 14px rgba(0,0,0,0.45)` | Default card |
| `--lift-2` | `0 1px 0 rgba(255,240,210,0.06) inset, 0 14px 36px rgba(0,0,0,0.55), 0 4px 10px rgba(0,0,0,0.35)` | Hero card |
| `--gold-shadow` | `0 8px 24px rgba(201,150,58,0.32), 0 0 0 1px rgba(228,190,111,0.4) inset` | Gold CTA buttons |

### Motion

| Token | Value |
|-------|-------|
| `--spring` | `cubic-bezier(0.2, 0.9, 0.2, 1.0)` |

---

## Key Component Patterns

### 1. Gold CTA Button (Primary Action)
- Background: `linear-gradient(180deg, var(--gold-bright), var(--gold))`
- Border: `1px solid var(--gold-deep)`
- Color: `#0a0a0a` (near-black text)
- Border-radius: `12px`
- Min-height: `48px` (mobile), `40px` (desktop)
- Box-shadow: `var(--gold-shadow)`
- Font: 13–14px, weight 600

### 2. Stage Pills (Pipeline Status)
- Border-radius: `99px`
- Font: Bebas Neue, 9px, letter-spacing 0.18em
- Each stage has its own soft bg + color pair from the stage palette

### 3. 5-Stage Progress Bar
- 5 segments with `4px` gap
- Each segment: `height: 4px`, `border-radius: 2px`
- Filled segments use stage color; empty use `var(--surface-2)`

### 4. Cockpit Headline (Job Detail)
- Contract value as hero number (Bebas Neue, large)
- Margin % alongside
- Progress bar showing billed vs remaining
- Next-action card with gold CTA

### 5. AI Compose — Draft-as-Hero
- Channel tabs (Text / Email / Voicemail) at top
- Draft message is the visual centerpiece — styled as a real phone text bubble (blue #2c6cf2), email letterhead, or voice waveform
- Below: AI fact tokens (pills showing what data was used)
- Below: Tone + Length adjuster chips (gold when selected)
- Bottom CTA bar with Send

### 6. Estimate Builder
- Scope input with voice button
- Line items as numbered rows
- Margin slider: gold circular thumb on gradient track (15–50% range)
- Proposal preview: cream paper (#fbf6ed) with dark text, letterhead style

### 7. Money Owed — Aging Waterfall
- 4-bucket aging strip (0–14d, 15–30d, 31–60d, 60+d)
- Each bucket has colored bar + amount
- Invoice list with age badge (colored by severity)
- AI follow-up panel with suggested next action

### 8. Client Card Pattern
- Avatar circle (initials, 38–56px, gold-tinted bg for top clients)
- Name + role, lifetime value as stamp number
- 3-cell strip: Active jobs | Owes | Last contact

### 9. Desktop Layout
- Fixed left sidebar (240px) with nav items + workspace brand
- Top bar with breadcrumbs, search (`⌘K`), notifications, avatar
- Content area with `dt-card` cards (border: `1px solid var(--hair)`, radius: `14px`, bg: `var(--surface-1)`)

### 10. Mobile Bottom Nav
- 4 tabs: Home, Jobs, Schedule, More
- Active tab: gold icon + label
- Fixed bottom, with home bar indicator below

---

## Interactions & Behavior

### Navigation
- Mobile: Bottom tab bar switches between Home, Jobs, Schedule, More
- Mobile: Nav menu (screen 11) slides up as a full sheet
- Desktop: Sidebar nav switches main content area
- Job cards → Job Detail; Client rows → Client detail

### State Toggles
- Jobs screen: filter pills (All / Lead / Quote / Active / Won)
- Schedule: state pills (All / Live / Upcoming / Done)
- Estimate: Builder ↔ Preview tab switch
- Clients: filter chips (All / Top / Active jobs / Owes / Cold)
- Money Owed: view toggle (By client / By age / By job)
- AI Compose: channel tabs (Text / Email / Voicemail), tone chips, length chips

### Interactive Controls
- Estimate margin slider: range input 15–50%, updates client total + profit live
- Voice recording button: toggles recording state with pulse animation
- Expandable transcript rail: play button + expand/collapse

### Animations
- `livePulse`: keyframe animation on live-status dots (opacity 1→0.4→1, 1.4s)
- Recording ring: scale 1→1.5 with fade, 1.6s
- Spring easing: `cubic-bezier(0.2, 0.9, 0.2, 1.0)` for transitions

---

## Fonts & Assets

### Google Fonts (load in production)
- **DM Sans**: weights 400, 500, 600, 700 (variable opsz 9–40)
- **Instrument Serif**: italic only

### Local Font
- **Bebas Neue**: `fonts/BebasNeue-Regular.ttf` — used for all numbers/amounts via `.stamp` class

### No Image Assets
All imagery in the prototypes is SVG placeholder (gradient rectangles simulating construction photos). Production should use real site photos. The design system note: "Real site photos lift cards. Synthetic gradients are a placeholder, not a style."

---

## Design Principles (from the system sheet)

1. **Margin over motion** — Every job card shows margin first. The number is the design.
2. **Quiet, then gold** — Field Gold is rare: italic accents, primary CTAs, won state. Never decorative.
3. **Progress as object** — Pipeline stages have weight, color, step count. They are the spine.
4. **Owner-grade density** — Builders run 11+ jobs. Cards must scan in under a second.
5. **Photo as proof** — Real site photos lift cards.
6. **Numbers in stamp** — Bebas Neue, tabular. Money and counts read like a job invoice.

---

## Files in This Package

| File | Purpose |
|------|---------|
| `tokens.css` | All CSS custom properties (colors, type, radius, shadows) |
| `styles.css` | Base component styles (cards, jobs, home, detail, system sheet) |
| `styles-workflows.css` | Workflow screen styles (clients, leads, notes, estimate, compose, owed) |
| `styles-refine.css` | Refinement layer (density, dispatch, compose hero, desktop, print) |
| `screens-home.jsx` | HomeScreen, AppHeader, BottomNav |
| `screens-jobs.jsx` | JobsScreen |
| `screens-schedule-estimate.jsx` | ScheduleScreen, EstimateScreen (builder + preview) |
| `screens-detail.jsx` | Legacy JobDetailScreen (superseded — reference only) |
| `screens-detail-est-owed.jsx` | JobDetailRealScreen, EstimateAIScreen (legacy), OwedScreen |
| `screens-workflows.jsx` | ClientsScreen, NewLeadScreen, NotesScreen |
| `screens-compose-nav.jsx` | ComposeScreen (draft-as-hero), NavScreen |
| `desktop.jsx` | DesktopHome, DesktopJobs, DesktopSidebar |
| `desktop-flows-1.jsx` | DesktopJobDetail, DesktopClients, DTopbar |
| `desktop-flows-2.jsx` | DesktopOwed, DesktopEstimate, DesktopCompose |
| `screens-system.jsx` | SystemSheet (design system reference) |
| `app.jsx` | Canvas layout with all artboards + status badges |
| `Fieldhorse v3.html` | Main canvas file — open this to see all screens |
| `fonts/BebasNeue-Regular.ttf` | Bebas Neue font file |

### Legacy files (do not implement)
- `screens-detail.jsx` → `JobDetailScreen` — superseded by `JobDetailRealScreen`
- `EstimateAIScreen` in `screens-detail-est-owed.jsx` — superseded by `EstimateScreen`
- `design-canvas.jsx` — canvas chrome, not product UI
- `app.jsx` — canvas layout, not product UI
