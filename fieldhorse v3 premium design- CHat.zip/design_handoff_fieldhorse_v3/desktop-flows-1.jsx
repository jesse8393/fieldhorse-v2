/* global React */
// ============================================================
// DESKTOP FLOWS — Job Detail, Clients, Owed, Estimate, Compose
// ============================================================

// shared topbar
window.DTopbar = function DTopbar({ crumbs }) { return (
  <div className="dt-topbar">
    <div className="dt-topbar__crumb">
      {crumbs.map((c, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span style={{ opacity: 0.4 }}> · </span>}
          {i === crumbs.length - 1 ? <b>{c}</b> : <span>{c}</span>}
        </React.Fragment>
      ))}
    </div>
    <div className="dt-topbar__actions">
      <div className="dt-search">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
        <span>Search jobs, clients, invoices…</span>
        <span style={{ marginLeft: 'auto', fontSize: 10, padding: '2px 6px', border: '1px solid var(--hair)', borderRadius: 4, color: 'var(--ink-3)' }}>⌘K</span>
      </div>
      <button className="icon-btn icon-btn--dot">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
        <span className="icon-btn__dot"></span>
      </button>
      <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg, #3a2a18, #1a1208)', border: '1px solid var(--hair-gold)', display: 'grid', placeItems: 'center', fontFamily: 'var(--f-stamp)', fontSize: 12, color: 'var(--gold-bright)', letterSpacing: '0.06em' }}>JP</div>
    </div>
  </div>
); };
const DTopbar = window.DTopbar;

// ============================================================
// 03 · JOB DETAIL — full cockpit
// ============================================================
window.DesktopJobDetail = function DesktopJobDetail() {
  return (
    <div className="desktop-frame">
      <DesktopSidebar active="jobs" />
      <div className="dt-main">
        <DTopbar crumbs={['PARKER', 'Jobs', 'MMC Properties · Summer Creek']} />

        <div className="dt-content">
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 24 }}>
            <div style={{ flex: 1 }}>
              <div className="eyebrow" style={{ marginBottom: 8 }}>JOB-2024-0061 · ACTIVE</div>
              <h1 className="dt-h1" style={{ fontSize: 38 }}>Summer Creek <em className="gold-italic">framing.</em></h1>
              <p className="dt-h1__sub">MMC Properties · 412 Summer Creek Dr · framing closeout, target Apr 30</p>
              <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                <span className="pill pill--good"><span style={{ width: 6, height: 6, borderRadius: '50%', background: 'currentColor', boxShadow: '0 0 6px currentColor', display: 'inline-block', marginRight: 6 }}></span>On schedule</span>
                <span className="pill">Margin 28%</span>
                <span className="pill">3 hands on site</span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="icon-btn"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg></button>
              <button className="icon-btn"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></button>
              <button style={{ padding: '10px 20px', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold))', color: '#1a1208', border: 0, borderRadius: 999, fontWeight: 600, fontSize: 13, cursor: 'pointer', boxShadow: '0 4px 14px rgba(201,150,58,0.32)' }}>Add change order</button>
            </div>
          </div>

          {/* 3-cell financial headline */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginTop: 28 }}>
            <div className="dt-card" style={{ padding: 20 }}>
              <div className="eyebrow" style={{ marginBottom: 10 }}>CONTRACT</div>
              <div className="stamp" style={{ fontSize: 32, color: 'var(--ink)', lineHeight: 1 }}>$84,200</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 6 }}>+$2,400 in approved COs</div>
            </div>
            <div className="dt-card" style={{ padding: 20 }}>
              <div className="eyebrow" style={{ marginBottom: 10 }}>BILLED</div>
              <div className="stamp" style={{ fontSize: 32, color: 'var(--ink)', lineHeight: 1 }}>$58,940</div>
              <div style={{ height: 4, background: 'var(--surface-2)', borderRadius: 2, marginTop: 10, overflow: 'hidden' }}>
                <div style={{ width: '70%', height: '100%', background: 'var(--gold-bright)' }}></div>
              </div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 6 }}>70% of contract · $25,260 remaining</div>
            </div>
            <div className="dt-card" style={{ padding: 20 }}>
              <div className="eyebrow" style={{ marginBottom: 10 }}>MARGIN · LIVE</div>
              <div className="stamp" style={{ fontSize: 32, color: 'var(--good)', lineHeight: 1 }}>28<span style={{ fontSize: 18, opacity: 0.6 }}>%</span></div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 6 }}>Bid: 26% · trending +2pt</div>
            </div>
          </div>

          {/* Two-column work area */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 16, marginTop: 16 }}>
            {/* Left col */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Phase progress */}
              <div className="dt-card" style={{ padding: 22 }}>
                <div className="block__head" style={{ marginBottom: 16 }}>
                  <div className="eyebrow">5-step pipeline</div>
                  <span className="pill pill--gold">Step 4 of 5 · Framing</span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 0, position: 'relative' }}>
                  {[
                    { n: '01', l: 'Lead', d: 'Mar 02' },
                    { n: '02', l: 'Estimate', d: 'Mar 14' },
                    { n: '03', l: 'Contract', d: 'Mar 22' },
                    { n: '04', l: 'Build', d: 'Apr 01', on: true },
                    { n: '05', l: 'Closeout', d: '—' },
                  ].map((s, i, a) => (
                    <div key={i} style={{ position: 'relative', paddingTop: 24 }}>
                      {i < a.length - 1 && <div style={{ position: 'absolute', top: 11, left: '50%', right: -8, height: 1, background: i < 3 ? 'var(--gold-bright)' : 'var(--hair)' }}></div>}
                      <div style={{
                        width: 24, height: 24, borderRadius: '50%',
                        background: i <= 3 ? 'linear-gradient(135deg, var(--gold-bright), var(--gold))' : 'var(--surface-2)',
                        border: '1px solid ' + (i <= 3 ? 'transparent' : 'var(--hair)'),
                        position: 'absolute', top: 0, left: 'calc(50% - 12px)',
                        display: 'grid', placeItems: 'center',
                        fontFamily: 'var(--f-stamp)', fontSize: 10, color: i <= 3 ? '#1a1208' : 'var(--ink-3)',
                        boxShadow: s.on ? '0 0 0 4px rgba(228,190,111,0.15)' : 'none',
                      }}>{i < 3 ? '✓' : s.n}</div>
                      <div style={{ textAlign: 'center', marginTop: 8 }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: s.on ? 'var(--gold-bright)' : (i < 3 ? 'var(--ink-2)' : 'var(--ink-3)') }}>{s.l}</div>
                        <div className="stamp" style={{ fontSize: 9, color: 'var(--ink-3)', marginTop: 3 }}>{s.d}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Schedule + Tasks */}
              <div className="dt-card" style={{ padding: 22 }}>
                <div className="block__head" style={{ marginBottom: 14 }}>
                  <div className="eyebrow">Phase tasks · Framing</div>
                  <button className="link">+ Add task</button>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                  {[
                    { t: 'Sheathing — south &amp; west walls', s: 'Marco · 4 hrs', done: true },
                    { t: 'Window rough-ins (8 openings)', s: 'Tim · 6 hrs', done: true },
                    { t: 'Roll painting · framing close', s: 'Tim, Marco, Jeff · 8 hrs · ON SITE NOW', live: true },
                    { t: 'Replace ~8\' rotted bottom plate · SW', s: 'Marco · 4 hrs · queued', done: false },
                    { t: 'Final framing inspection', s: 'Mon Apr 30 · scheduled', done: false },
                  ].map((row, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 0', borderBottom: i < 4 ? '1px solid var(--hair)' : '0' }}>
                      <div style={{
                        width: 18, height: 18, borderRadius: '50%',
                        border: '1.5px solid ' + (row.done ? 'var(--good)' : (row.live ? 'var(--gold-bright)' : 'var(--hair-strong)')),
                        background: row.done ? 'var(--good)' : (row.live ? 'rgba(228,190,111,0.15)' : 'transparent'),
                        display: 'grid', placeItems: 'center',
                        flexShrink: 0,
                      }}>
                        {row.done && <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#0c1410" strokeWidth="3.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>}
                        {row.live && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--gold-bright)', animation: 'livePulse 1.4s infinite' }}></span>}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 500, color: row.done ? 'var(--ink-3)' : 'var(--ink)', textDecoration: row.done ? 'line-through' : 'none' }} dangerouslySetInnerHTML={{ __html: row.t }}></div>
                        <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{row.s}</div>
                      </div>
                      {row.live && <span className="pill pill--good">Live</span>}
                    </div>
                  ))}
                </div>
              </div>

              {/* Activity log */}
              <div className="dt-card" style={{ padding: 22 }}>
                <div className="block__head" style={{ marginBottom: 14 }}>
                  <div className="eyebrow">Activity</div>
                  <button className="link">View all</button>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {[
                    { t: 'Voice note · 3 action items captured', m: 'JP · 8 min ago · Notes', g: true },
                    { t: 'Tom approved sconce add-on verbally', m: 'Yesterday 4:22 PM · Quote update' },
                    { t: 'Crew arrived 7:12 AM · 3 hands', m: 'Today 7:14 AM · Auto-logged' },
                    { t: 'Inspection passed · framing rough', m: 'Apr 25 · Site visit' },
                  ].map((row, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                      <span style={{ width: 6, height: 6, borderRadius: '50%', background: row.g ? 'var(--gold-bright)' : 'var(--ink-3)', marginTop: 6, flexShrink: 0, boxShadow: row.g ? '0 0 8px var(--gold-bright)' : 'none' }}></span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, color: 'var(--ink)' }}>{row.t}</div>
                        <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{row.m}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right rail */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Next action card */}
              <div className="dt-card" style={{ padding: 22, background: 'linear-gradient(160deg, rgba(228,190,111,0.08), var(--surface-1))', borderColor: 'var(--hair-gold)' }}>
                <div className="eyebrow eyebrow--gold" style={{ marginBottom: 8 }}>Next action</div>
                <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.3, marginBottom: 6 }}>Schedule final framing inspection</div>
                <div style={{ fontSize: 12, color: 'var(--ink-3)', marginBottom: 16 }}>Inspector booking opens tomorrow · target Mon Apr 30 AM</div>
                <button style={{ width: '100%', padding: '12px', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold))', color: '#1a1208', border: 0, borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Book inspection</button>
              </div>

              {/* Client card */}
              <div className="dt-card" style={{ padding: 22 }}>
                <div className="eyebrow" style={{ marginBottom: 14 }}>Client</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
                  <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'linear-gradient(135deg, #3a2a18, #1a1208)', border: '1px solid var(--hair-gold)', display: 'grid', placeItems: 'center', fontFamily: 'var(--f-stamp)', color: 'var(--gold-bright)', fontSize: 14 }}>MM</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--ink)' }}>MMC Properties</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>Tom Mitchell · primary contact</div>
                  </div>
                  <span className="pill pill--gold">TOP 5</span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0, paddingTop: 14, borderTop: '1px solid var(--hair)' }}>
                  {[
                    ['LIFETIME', '$340K'],
                    ['JOBS', '4'],
                    ['ON-TIME', '100%'],
                  ].map(([l, v], i) => (
                    <div key={i} style={{ paddingLeft: i === 0 ? 0 : 12, borderLeft: i === 0 ? 'none' : '1px solid var(--hair)' }}>
                      <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', color: 'var(--ink-3)', marginBottom: 4 }}>{l}</div>
                      <div className="stamp" style={{ fontSize: 16, color: 'var(--ink)' }}>{v}</div>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: 6, marginTop: 14 }}>
                  <button style={{ flex: 1, padding: '8px', background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 8, color: 'var(--ink-2)', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>Call</button>
                  <button style={{ flex: 1, padding: '8px', background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 8, color: 'var(--ink-2)', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>Text</button>
                  <button style={{ flex: 1, padding: '8px', background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 8, color: 'var(--ink-2)', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>Email</button>
                </div>
              </div>

              {/* Crew & schedule */}
              <div className="dt-card" style={{ padding: 22 }}>
                <div className="eyebrow" style={{ marginBottom: 14 }}>Crew on site · today</div>
                {[
                  { i: 'TM', n: 'Tim Calhoun', r: 'Lead carpenter', h: '8:12 AM' },
                  { i: 'MC', n: 'Marco Reyes', r: 'Carpenter', h: '8:14 AM' },
                  { i: 'JE', n: 'Jeff Eaton', r: 'Helper', h: '8:18 AM' },
                ].map((c, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: i < 2 ? '1px solid var(--hair)' : '0' }}>
                    <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'var(--surface-2)', border: '1px solid var(--hair)', display: 'grid', placeItems: 'center', fontFamily: 'var(--f-stamp)', fontSize: 10, color: 'var(--ink-2)' }}>{c.i}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--ink)' }}>{c.n}</div>
                      <div style={{ fontSize: 10, color: 'var(--ink-3)' }}>{c.r}</div>
                    </div>
                    <div className="stamp" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{c.h}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// 04 · CLIENTS — desktop list w/ side detail
// ============================================================
window.DesktopClients = function DesktopClients() {
  const clients = [
    { i: 'MM', n: 'MMC Properties', t: 'Top 5 · Property mgmt', a: '$340K', j: '4 active', on: true },
    { i: 'JR', n: 'Jeff Roy', t: 'Estimate pending', a: '$26K', j: '1 quote' },
    { i: 'HN', n: 'Heather Neighbor', t: '42d overdue · $12,400', a: '$48K', j: '0 active', alert: true },
    { i: 'TJ', n: 'Tom Jameson', t: 'Active · framing', a: '$184K', j: '2 active' },
    { i: 'LG', n: 'Lily Grace North', t: 'Site visit booked', a: '$22K', j: '1 quote' },
    { i: 'BC', n: 'Bishop Construction', t: 'Sub partnership', a: '$96K', j: '1 active' },
    { i: 'CW', n: 'Carl Wallace', t: 'Closed · 30d', a: '$74K', j: '0 active' },
  ];
  return (
    <div className="desktop-frame">
      <DesktopSidebar active="clients" />
      <div className="dt-main">
        <DTopbar crumbs={['PARKER', 'Clients']} />

        <div className="dt-content">
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 24 }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 8 }}>47 clients · $1.84M lifetime</div>
              <h1 className="dt-h1" style={{ fontSize: 38 }}>Clients</h1>
              <p className="dt-h1__sub">3 owe a balance · $24,300 outstanding</p>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="icon-btn"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M22 3H2l8 9.5V21l4-2v-6.5z"/></svg></button>
              <button style={{ padding: '10px 20px', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold))', color: '#1a1208', border: 0, borderRadius: 999, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>+ New client</button>
            </div>
          </div>

          {/* KPI strip */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 16 }}>
            {[
              ['Lifetime billed', '$1.84M', 'across 47 clients'],
              ['Active jobs', '11', '4 finishing this month'],
              ['Outstanding', '$24.3K', '3 clients owe balance', 'alert'],
              ['Avg job size', '$39K', '+8% vs 2025'],
            ].map(([l, v, s, k], i) => (
              <div key={i} className="dt-card" style={{ padding: 20 }}>
                <div className="eyebrow" style={{ marginBottom: 10 }}>{l}</div>
                <div className="stamp" style={{ fontSize: 26, color: k === 'alert' ? '#E08B7A' : 'var(--ink)', lineHeight: 1 }}>{v}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 6 }}>{s}</div>
              </div>
            ))}
          </div>

          {/* List + detail */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 16 }}>
            <div className="dt-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '14px 20px', display: 'flex', gap: 12, alignItems: 'center', borderBottom: '1px solid var(--hair)' }}>
                <div className="dt-search" style={{ flex: 1, margin: 0 }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
                  <span>Search clients</span>
                </div>
                <div style={{ display: 'inline-flex', background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 999, padding: 3 }}>
                  {['All', 'Top', 'Active', 'Owes'].map((t, i) => (
                    <button key={t} style={{ padding: '6px 12px', background: i === 0 ? 'var(--gold-soft)' : 'none', border: 0, borderRadius: 999, color: i === 0 ? 'var(--gold-bright)' : 'var(--ink-2)', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>{t}</button>
                  ))}
                </div>
              </div>
              {clients.map((c, i) => (
                <div key={i} style={{
                  padding: '14px 20px',
                  display: 'flex', alignItems: 'center', gap: 14,
                  borderBottom: i < clients.length - 1 ? '1px solid var(--hair)' : '0',
                  background: c.on ? 'var(--gold-soft)' : 'transparent',
                  cursor: 'pointer',
                }}>
                  <div style={{
                    width: 40, height: 40, borderRadius: '50%',
                    background: c.on ? 'linear-gradient(135deg, #3a2a18, #1a1208)' : 'var(--surface-2)',
                    border: '1px solid ' + (c.on ? 'var(--hair-gold)' : 'var(--hair)'),
                    display: 'grid', placeItems: 'center',
                    fontFamily: 'var(--f-stamp)', fontSize: 12,
                    color: c.on ? 'var(--gold-bright)' : 'var(--ink-2)',
                  }}>{c.i}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>{c.n}</div>
                    <div style={{ fontSize: 11, color: c.alert ? '#E08B7A' : 'var(--ink-3)', marginTop: 2 }}>{c.t}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div className="stamp" style={{ fontSize: 14, color: 'var(--ink)' }}>{c.a}</div>
                    <div style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 2 }}>{c.j}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Detail */}
            <div className="dt-card" style={{ padding: 24 }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 18 }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'linear-gradient(135deg, #3a2a18, #1a1208)', border: '1px solid var(--hair-gold)', display: 'grid', placeItems: 'center', fontFamily: 'var(--f-stamp)', fontSize: 18, color: 'var(--gold-bright)' }}>MM</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--ink)' }}>MMC Properties</div>
                  <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 3 }}>Tom Mitchell · primary · since Jan 2023</div>
                  <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                    <span className="pill pill--gold">TOP 5</span>
                    <span className="pill pill--good">100% on-time pay</span>
                  </div>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0, padding: '14px 0', borderTop: '1px solid var(--hair)', borderBottom: '1px solid var(--hair)' }}>
                {[
                  ['LIFETIME', '$340K'],
                  ['JOBS', '4'],
                  ['MARGIN AVG', '27%'],
                ].map(([l, v], i) => (
                  <div key={i} style={{ paddingLeft: i === 0 ? 0 : 14, borderLeft: i === 0 ? 'none' : '1px solid var(--hair)' }}>
                    <div style={{ fontSize: 9, fontWeight: 600, letterSpacing: '0.16em', color: 'var(--ink-3)', marginBottom: 4 }}>{l}</div>
                    <div className="stamp" style={{ fontSize: 18, color: 'var(--ink)' }}>{v}</div>
                  </div>
                ))}
              </div>
              <div className="eyebrow" style={{ margin: '18px 0 12px' }}>Active jobs · 4</div>
              {[
                ['Summer Creek framing', 'Active · 70% billed', '$84K'],
                ['Olive Branch reno', 'Active · 30% billed', '$56K'],
                ['Maple Park rebuild', 'Estimate', '$120K'],
                ['Mill Creek deck', 'Closed · paid', '$38K'],
              ].map((row, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: i < 3 ? '1px solid var(--hair)' : 0 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--ink)' }}>{row[0]}</div>
                    <div style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 2 }}>{row[1]}</div>
                  </div>
                  <div className="stamp" style={{ fontSize: 12, color: 'var(--ink-2)' }}>{row[2]}</div>
                </div>
              ))}
              <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
                <button style={{ flex: 1, padding: '10px', background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 8, color: 'var(--ink-2)', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Call</button>
                <button style={{ flex: 1, padding: '10px', background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 8, color: 'var(--ink-2)', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Email</button>
                <button style={{ flex: 1, padding: '10px', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold))', color: '#1a1208', border: 0, borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>+ New job</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
