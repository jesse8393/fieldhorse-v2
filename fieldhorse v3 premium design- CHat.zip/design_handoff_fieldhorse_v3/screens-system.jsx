/* global React */

window.SystemSheet = function SystemSheet() {
  const palette = [
    { name: 'Onyx',      val: '#0B0907', label: 'page' },
    { name: 'Surface 1', val: '#141110', label: 'card' },
    { name: 'Surface 2', val: '#1C1814', label: 'inner' },
    { name: 'Hair gold', val: '#3a2a18', label: 'border' },
    { name: 'Ink',       val: '#F2EDE4', label: 'primary' },
    { name: 'Ink 3',     val: 'rgba(242,237,228,0.55)', label: 'meta', isAlpha: true },
  ];
  const brand = [
    { name: 'Field Gold',  val: '#C9963A', label: 'brand' },
    { name: 'Gold Bright', val: '#E8B865', label: 'accent' },
    { name: 'Gold Hot',    val: '#E4BE6F', label: 'glow' },
    { name: 'Gold Deep',   val: '#8C6F30', label: 'shadow' },
  ];
  const stages = [
    { name: 'Lead',   val: '#6B7CA8', label: 'steel-blue' },
    { name: 'Quote',  val: '#B07A4A', label: 'bronze' },
    { name: 'Active', val: '#4F8C5E', label: 'moss' },
    { name: 'Won',    val: '#C9963A', label: 'gold' },
    { name: 'Closed', val: '#5C5C5C', label: 'steel' },
    { name: 'Alert',  val: '#C0392B', label: 'cold' },
  ];

  const Swatch = ({ name, val, label, isAlpha }) => (
    <div className="swatch">
      <div className="swatch__chip" style={{ background: val, backgroundImage: isAlpha ? `linear-gradient(45deg, #1a1410 25%, transparent 25%, transparent 75%, #1a1410 75%), linear-gradient(45deg, #1a1410 25%, transparent 25%, transparent 75%, #1a1410 75%), ${val}` : undefined, backgroundSize: isAlpha ? '12px 12px' : undefined, backgroundPosition: isAlpha ? '0 0, 6px 6px' : undefined }}></div>
      <div className="swatch__body">
        <div className="swatch__name">{name}</div>
        <div className="swatch__val">{val.toUpperCase()} · {label}</div>
      </div>
    </div>
  );

  return (
    <div className="sys-sheet">
      {/* Header */}
      <div className="sys-sheet__head">
        <div className="sys-sheet__co">PARKER · CONSTRUCTION CO. · DESIGN SYSTEM v3</div>
        <h1 className="sys-sheet__h1">A premium operating system for <em className="gold-italic">high-revenue builders.</em></h1>
        <p className="sys-sheet__sub">Warm onyx canvas. Precision gold. Stage-tinted jewels. Built for owners who think in margin and progress, not buttons and tabs.</p>
      </div>

      {/* Foundation palette */}
      <div className="sys-block">
        <div className="sys-block__head">
          <div className="sys-block__title">Foundation · Onyx surfaces</div>
          <div className="sys-block__hint">Never blue. Never neutral. Always warm.</div>
        </div>
        <div className="sys-grid--swatches">
          {palette.map(p => <Swatch key={p.name} {...p} />)}
        </div>
      </div>

      {/* Brand gold */}
      <div className="sys-block">
        <div className="sys-block__head">
          <div className="sys-block__title">Brand · Field Gold</div>
          <div className="sys-block__hint">Used precisely — italic accents, primary CTAs, won state, FAB.</div>
        </div>
        <div className="sys-grid--swatches">
          {brand.map(p => <Swatch key={p.name} {...p} />)}
        </div>
      </div>

      {/* Stage palette */}
      <div className="sys-block">
        <div className="sys-block__head">
          <div className="sys-block__title">Pipeline · Stage palette</div>
          <div className="sys-block__hint">Muted jewel tones — semantic without being clinical.</div>
        </div>
        <div className="sys-grid--swatches">
          {stages.map(p => <Swatch key={p.name} {...p} />)}
        </div>
      </div>

      {/* Type */}
      <div className="sys-block">
        <div className="sys-block__head">
          <div className="sys-block__title">Type · Three voices</div>
          <div className="sys-block__hint">Bebas for numbers. DM Sans for body. Instrument Serif italic for warmth.</div>
        </div>
        <div className="sys-grid--type">
          <div className="type-row">
            <div className="type-row__lbl">Display · 56–60px<small>DM SANS 600 + ITALIC SERIF</small></div>
            <div style={{ fontSize: 56, fontWeight: 600, letterSpacing: '-0.025em', lineHeight: 1, color: 'var(--ink)' }}>
              Good morning, <em className="gold-italic" style={{ fontSize: 60 }}>Jesse.</em>
            </div>
          </div>
          <div className="type-row">
            <div className="type-row__lbl">H1 · 28–32px<small>DM SANS 600</small></div>
            <div style={{ fontSize: 32, fontWeight: 600, letterSpacing: '-0.025em', lineHeight: 1.05, color: 'var(--ink)' }}>
              Jobs <em className="gold-italic" style={{ fontSize: 36 }}>&amp; Pipeline</em>
            </div>
          </div>
          <div className="type-row">
            <div className="type-row__lbl">Stamp · numbers<small>BEBAS NEUE · TABULAR</small></div>
            <div className="stamp" style={{ fontSize: 56, color: 'var(--ink)', lineHeight: 1 }}>
              <span style={{
                background: 'linear-gradient(95deg, #B17F1F 0%, #E6B14B 50%, #C9963A 100%)',
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}>$136,000</span>
            </div>
          </div>
          <div className="type-row">
            <div className="type-row__lbl">Body · 13px<small>DM SANS 500</small></div>
            <div style={{ fontSize: 13, color: 'var(--ink-2)', maxWidth: 480, lineHeight: 1.5 }}>
              Three crews on site. All green. <b style={{ color: 'var(--ink)' }}>$24,300</b> invoicing this week. The only thing that needs your eyes today is two leads gone cold and the MMC quote.
            </div>
          </div>
          <div className="type-row">
            <div className="type-row__lbl">Eyebrow · 9–11px<small>DM SANS 700 · 0.22em TRACK</small></div>
            <div className="eyebrow" style={{ fontSize: 11 }}>NEEDS ATTENTION TODAY · 3</div>
          </div>
        </div>
      </div>

      {/* Components */}
      <div className="sys-block">
        <div className="sys-block__head">
          <div className="sys-block__title">Components · Atoms</div>
          <div className="sys-block__hint">Stage pills, progress bars, KPI tags, action chips, pills.</div>
        </div>
        <div className="sys-grid--components">

          <div className="comp-cell">
            <div className="comp-cell__title">Stage pills</div>
            <div className="comp-cell__row">
              <span className="stage-pill stage-pill--lead">LEAD</span>
              <span className="stage-pill stage-pill--quote">QUOTE</span>
              <span className="stage-pill stage-pill--active">ACTIVE</span>
              <span className="stage-pill stage-pill--won">WON</span>
              <span className="stage-pill stage-pill--closed">CLOSED</span>
            </div>
          </div>

          <div className="comp-cell">
            <div className="comp-cell__title">Pipeline progress · 5-stage</div>
            <div className="comp-cell__row" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span className="stage-pill stage-pill--quote">QUOTE</span>
                <div className="stage-bar" style={{ flex: 1 }}>
                  <div className="stage-bar__seg is-on is-on--quote"></div>
                  <div className="stage-bar__seg is-on is-on--quote"></div>
                  <div className="stage-bar__seg"></div>
                  <div className="stage-bar__seg"></div>
                  <div className="stage-bar__seg"></div>
                </div>
                <span className="stage-step">2/5</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span className="stage-pill stage-pill--active">ACTIVE</span>
                <div className="stage-bar" style={{ flex: 1 }}>
                  <div className="stage-bar__seg is-on is-on--active"></div>
                  <div className="stage-bar__seg is-on is-on--active"></div>
                  <div className="stage-bar__seg is-on is-on--active"></div>
                  <div className="stage-bar__seg"></div>
                  <div className="stage-bar__seg"></div>
                </div>
                <span className="stage-step">3/5</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span className="stage-pill stage-pill--won">WON</span>
                <div className="stage-bar" style={{ flex: 1 }}>
                  <div className="stage-bar__seg is-on is-on--won"></div>
                  <div className="stage-bar__seg is-on is-on--won"></div>
                  <div className="stage-bar__seg is-on is-on--won"></div>
                  <div className="stage-bar__seg is-on is-on--won"></div>
                  <div className="stage-bar__seg is-on is-on--won"></div>
                </div>
                <span className="stage-step">5/5</span>
              </div>
            </div>
          </div>

          <div className="comp-cell">
            <div className="comp-cell__title">Filters &amp; chips</div>
            <div className="comp-cell__row">
              <button className="filt filt--on">All <span className="filt__c">11</span></button>
              <button className="filt">Lead <span className="filt__c">2</span></button>
              <button className="filt">Quote <span className="filt__c">2</span></button>
              <button className="filt">Active <span className="filt__c">6</span></button>
            </div>
          </div>

          <div className="comp-cell">
            <div className="comp-cell__title">Status pills</div>
            <div className="comp-cell__row">
              <span className="pill">Upcoming</span>
              <span className="pill pill--good">Live</span>
              <span className="pill pill--lead">Walkthrough</span>
              <span className="pill pill--gold">Draft</span>
            </div>
          </div>

          <div className="comp-cell">
            <div className="comp-cell__title">Trend badge</div>
            <div className="comp-cell__row">
              <span className="trend">
                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m5 12 7-7 7 7"/><path d="M12 19V5"/></svg>
                +6.1%
              </span>
            </div>
          </div>

          <div className="comp-cell">
            <div className="comp-cell__title">CTA buttons</div>
            <div className="comp-cell__row">
              <button className="est-actbar__btn est-actbar__btn--ghost" style={{ padding: '10px 16px' }}>Preview</button>
              <button className="est-actbar__btn est-actbar__btn--primary" style={{ padding: '10px 16px' }}>Send to client</button>
              <button className="detail-action__cta">Mark Done</button>
            </div>
          </div>

        </div>
      </div>

      {/* Principles */}
      <div className="sys-block" style={{ marginBottom: 0 }}>
        <div className="sys-block__head">
          <div className="sys-block__title">Principles</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 28 }}>
          {[
            { n: '01', t: 'Margin over motion', d: 'Every job card shows margin first. The number is the design.' },
            { n: '02', t: 'Quiet, then gold', d: 'Field Gold is rare — italic accents, primary CTAs, won state. Never decorative.' },
            { n: '03', t: 'Progress as object', d: 'Pipeline stages have weight, color, and step count. They are the spine.' },
            { n: '04', t: 'Owner-grade density', d: 'Builders run 11+ jobs at once. Cards must scan in under a second.' },
            { n: '05', t: 'Photo as proof', d: 'Real site photos lift cards. Synthetic gradients are a placeholder, not a style.' },
            { n: '06', t: 'Numbers in stamp', d: 'Bebas Neue, tabular. Money and counts read like a job invoice.' },
          ].map(p => (
            <div key={p.n}>
              <div className="stamp" style={{ fontSize: 22, color: 'var(--gold-bright)', marginBottom: 10 }}>{p.n}</div>
              <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--ink)', marginBottom: 6, letterSpacing: '-0.005em' }}>{p.t}</div>
              <div style={{ fontSize: 12, color: 'var(--ink-3)', lineHeight: 1.5 }}>{p.d}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
