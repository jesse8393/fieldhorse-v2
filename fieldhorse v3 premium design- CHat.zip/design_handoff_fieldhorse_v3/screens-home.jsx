/* global React */
const { useState, useMemo } = React;

// ============================================================
// SHARED — header, nav, badges
// ============================================================
window.AppHeader = function AppHeader({ subtitle = 'Fieldhorse', onJobs }) {
  return (
    <div className="app-head">
      <div className="app-head__brand">
        <div className="app-head__fh">FH</div>
        <div className="app-head__name">
          <div className="app-head__co">PARKER</div>
          <div className="app-head__tag">{subtitle}</div>
        </div>
      </div>
      <div className="app-head__actions">
        <button className="icon-btn" aria-label="Search">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
        </button>
        <button className="icon-btn icon-btn--dot" aria-label="Notifications">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
          <span className="icon-btn__dot"></span>
        </button>
      </div>
    </div>
  );
};

window.BottomNav = function BottomNav({ active = 'home' }) {
  const items = [
    { id: 'home', label: 'Home', icon: <path d="M3 11 12 3l9 8M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"/> },
    { id: 'jobs', label: 'Jobs', icon: <><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/></> },
    { id: 'clients', label: 'Clients', icon: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></> },
    { id: 'schedule', label: 'Schedule', icon: <><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></> },
    { id: 'more', label: 'More', icon: <><circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/></> },
  ];
  return (
    <nav className="botnav">
      {items.map(it => (
        <button key={it.id} className={`botnav__tab ${active === it.id ? 'is-on' : ''}`}>
          {active === it.id && <span className="botnav__indicator" />}
          <svg width="20" height="20" viewBox="0 0 24 24" fill={it.id === 'more' ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">{it.icon}</svg>
          <span className="botnav__lbl">{it.label}</span>
        </button>
      ))}
    </nav>
  );
};

// ============================================================
// HOME SCREEN — refined daily exec brief
// ============================================================
window.HomeScreen = function HomeScreen() {
  return (
    <div className="screen">
      <AppHeader subtitle="Tuesday · Apr 28" />

      <div className="screen__body no-scroll">

        {/* Greeting + status strip */}
        <section className="hero">
          <div className="hero__top">
            <div style={{ minWidth: 0, flex: 1 }}>
              <div className="hero__date">TUESDAY · APR 28 · 9:41 AM</div>
              <h1 className="hero__title">Good morning, <em className="gold-italic">Jesse.</em></h1>
              <div className="hero__sub">
                <span className="hero__chip"><span className="hero__chip-dot" style={{ background: 'var(--good)' }} /> 3 crews on site</span>
                <span className="hero__sub-sep">·</span>
                <span className="hero__sub-text">Clear day · No delays</span>
              </div>
            </div>
            <div className="weather">
              <div className="weather__top">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--gold-bright)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M5 5l1.5 1.5M17.5 17.5 19 19M2 12h2M20 12h2M5 19l1.5-1.5M17.5 6.5 19 5"/></svg>
                <div className="weather__temp stamp">71°</div>
              </div>
              <div className="weather__cond">Partly cloudy</div>
            </div>
          </div>
        </section>

        {/* TOP PRIORITY — single hero alert */}
        <section className="top-prio">
          <div className="top-prio__rule"></div>
          <div className="top-prio__body">
            <div className="top-prio__head">
              <div className="top-prio__eye">
                <span className="top-prio__pulse"></span>
                NEEDS ATTENTION TODAY
              </div>
              <span className="top-prio__count stamp">3</span>
            </div>
            <div className="top-prio__title">2 leads gone cold &amp; <em className="gold-italic">$24K</em> due to invoice</div>
            <div className="top-prio__list">
              <button className="top-prio__row">
                <span className="top-prio__row-dot" style={{ background: 'var(--alert)' }}></span>
                <span className="top-prio__row-main">Follow up · <b>Heather Neighbor</b></span>
                <span className="top-prio__row-aux">8d cold</span>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
              </button>
              <button className="top-prio__row">
                <span className="top-prio__row-dot" style={{ background: 'var(--warn)' }}></span>
                <span className="top-prio__row-main">Quote review · <b>MMC Properties</b></span>
                <span className="top-prio__row-aux">$46K · sent 3d</span>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
              </button>
              <button className="top-prio__row">
                <span className="top-prio__row-dot" style={{ background: 'var(--gold-bright)' }}></span>
                <span className="top-prio__row-main">Invoice closeout · <b>Matthew Addition</b></span>
                <span className="top-prio__row-aux">$24,300 ready</span>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
              </button>
            </div>
          </div>
        </section>

        {/* Pipeline — hero card */}
        <section className="pipeline-hero">
          <div className="pipeline-hero__head">
            <div className="eyebrow">Total pipeline · 30 days</div>
            <span className="trend">
              <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m5 12 7-7 7 7"/><path d="M12 19V5"/></svg>
              +6.1%
            </span>
          </div>
          <div className="pipeline-hero__amt">
            <span className="stamp">$136,000</span>
          </div>
          <div className="pipeline-hero__sub">vs <b>$128,200</b> · prev. period · <b className="ink-2">11</b> open</div>

          {/* Sparkline */}
          <svg className="spark" viewBox="0 0 320 60" preserveAspectRatio="none">
            <defs>
              <linearGradient id="sparkfill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#E4BE6F" stopOpacity="0.32"/>
                <stop offset="100%" stopColor="#E4BE6F" stopOpacity="0"/>
              </linearGradient>
            </defs>
            <path d="M0,46 L26,42 L52,38 L78,30 L104,34 L130,28 L156,32 L182,22 L208,28 L234,18 L260,22 L286,12 L320,8 L320,60 L0,60 Z" fill="url(#sparkfill)"/>
            <path d="M0,46 L26,42 L52,38 L78,30 L104,34 L130,28 L156,32 L182,22 L208,28 L234,18 L260,22 L286,12 L320,8" fill="none" stroke="#E4BE6F" strokeWidth="1.5"/>
            <circle cx="320" cy="8" r="3" fill="#E4BE6F"/>
            <circle cx="320" cy="8" r="6" fill="#E4BE6F" opacity="0.18"/>
          </svg>

          <div className="pipeline-hero__breakdown">
            <div className="brk">
              <div className="brk__top">
                <span className="brk__dot" style={{ background: 'var(--won)', color: 'var(--gold-glow)' }}></span>
                <div className="brk__l">Won</div>
              </div>
              <div className="brk__amt stamp">$42K</div>
              <div className="brk__n"><span className="stamp">3</span> closed</div>
            </div>
            <div className="brk">
              <div className="brk__top">
                <span className="brk__dot" style={{ background: 'var(--active)', color: 'rgba(79,140,94,0.4)' }}></span>
                <div className="brk__l">Active</div>
              </div>
              <div className="brk__amt stamp">$56K</div>
              <div className="brk__n"><span className="stamp">4</span> in motion</div>
            </div>
            <div className="brk">
              <div className="brk__top">
                <span className="brk__dot" style={{ background: 'var(--lead)', color: 'rgba(107,124,168,0.4)' }}></span>
                <div className="brk__l">Lead</div>
              </div>
              <div className="brk__amt stamp">$38K</div>
              <div className="brk__n"><span className="stamp">4</span> warm</div>
            </div>
          </div>
        </section>

        {/* Today on Site — refined */}
        <section className="block">
          <div className="block__head">
            <div className="eyebrow">Today on site · 4 visits</div>
            <button className="link">Schedule →</button>
          </div>
          <div className="site-list">
            <div className="site-row site-row--live">
              <div className="site-row__time">
                <div className="site-row__hr stamp">8:15</div>
                <div className="site-row__ap">AM</div>
              </div>
              <div className="site-row__rule" style={{ background: 'var(--good)' }}>
                <span className="site-row__rule-now"></span>
              </div>
              <div className="site-row__main">
                <div className="site-row__name">MMC Properties</div>
                <div className="site-row__meta">Crew arrived · <b>3 hands</b> · Summer Creek rail</div>
              </div>
              <span className="pill pill--good">Live</span>
            </div>
            <div className="site-row">
              <div className="site-row__time">
                <div className="site-row__hr stamp">10:30</div>
                <div className="site-row__ap">AM</div>
              </div>
              <div className="site-row__rule" style={{ background: 'var(--gold)' }}></div>
              <div className="site-row__main">
                <div className="site-row__name">Matthew Addition</div>
                <div className="site-row__meta">Material delivery · <b>ETA 18 min</b></div>
              </div>
              <span className="pill">In 49m</span>
            </div>
            <div className="site-row">
              <div className="site-row__time">
                <div className="site-row__hr stamp">2:00</div>
                <div className="site-row__ap">PM</div>
              </div>
              <div className="site-row__rule" style={{ background: 'var(--lead)' }}></div>
              <div className="site-row__main">
                <div className="site-row__name">Jeff Roy</div>
                <div className="site-row__meta">Roof walkthrough · <b>w/ client</b></div>
              </div>
              <span className="pill">2:00 PM</span>
            </div>
            <div className="site-row">
              <div className="site-row__time">
                <div className="site-row__hr stamp">4:30</div>
                <div className="site-row__ap">PM</div>
              </div>
              <div className="site-row__rule" style={{ background: 'var(--quote)' }}></div>
              <div className="site-row__main">
                <div className="site-row__name">Lily Grace North</div>
                <div className="site-row__meta">Estimate site visit · concrete</div>
              </div>
              <span className="pill">4:30 PM</span>
            </div>
          </div>
        </section>

        {/* Quick actions — refined with primary action */}
        <section className="block block--noborder">
          <div className="block__head">
            <div className="eyebrow">Quick actions</div>
            <button className="link link--mute">Customize</button>
          </div>
          <div className="quick">
            <button className="quick__btn quick__btn--primary">
              <div className="quick__icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>
              </div>
              <span>Add Lead</span>
            </button>
            <button className="quick__btn">
              <div className="quick__icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h4"/></svg>
              </div>
              <span>New Quote</span>
            </button>
            <button className="quick__btn">
              <div className="quick__icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
              </div>
              <span>Schedule</span>
            </button>
            <button className="quick__btn">
              <div className="quick__icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
              </div>
              <span>Invoice</span>
            </button>
          </div>
        </section>

        {/* Pipeline preview — richer rows */}
        <section className="block">
          <div className="block__head">
            <div className="eyebrow">Top opportunities</div>
            <button className="link">Pipeline →</button>
          </div>
          <div className="pipe-list">
            <button className="pipe-row pipe-row--rich">
              <div className="pipe-row__rule" style={{ background: 'var(--gold)' }}></div>
              <div className="pipe-row__main">
                <div className="pipe-row__top">
                  <div className="pipe-row__client">MMC Properties</div>
                  <span className="pipe-row__amt-rich stamp">$46K</span>
                </div>
                <div className="pipe-row__bot">
                  <span className="stage-pill stage-pill--quote">QUOTE</span>
                  <span className="pipe-row__detail">Approval pending · <b>3d</b></span>
                  <span className="pipe-row__margin">38% <span>m.</span></span>
                </div>
              </div>
            </button>
            <button className="pipe-row pipe-row--rich">
              <div className="pipe-row__rule" style={{ background: 'var(--quote)' }}></div>
              <div className="pipe-row__main">
                <div className="pipe-row__top">
                  <div className="pipe-row__client">Jeff Roy</div>
                  <span className="pipe-row__amt-rich stamp">$24K</span>
                </div>
                <div className="pipe-row__bot">
                  <span className="stage-pill stage-pill--quote">QUOTE</span>
                  <span className="pipe-row__detail">Walkthrough today · <b>2 PM</b></span>
                  <span className="pipe-row__margin">24% <span>m.</span></span>
                </div>
              </div>
            </button>
            <button className="pipe-row pipe-row--rich">
              <div className="pipe-row__rule" style={{ background: 'var(--lead)' }}></div>
              <div className="pipe-row__main">
                <div className="pipe-row__top">
                  <div className="pipe-row__client">Lily Grace North</div>
                  <span className="pipe-row__amt-rich stamp">$17K</span>
                </div>
                <div className="pipe-row__bot">
                  <span className="stage-pill stage-pill--lead">LEAD</span>
                  <span className="pipe-row__detail">Site visit · <b>4:30 PM</b></span>
                  <span className="pipe-row__margin">— <span>m.</span></span>
                </div>
              </div>
            </button>
          </div>
        </section>

        <div className="bot-spacer"></div>
      </div>

      <BottomNav active="home" />
    </div>
  );
};
