/* global React */
// ============================================================
// DESKTOP FLOWS 2 — Money Owed, Estimate Builder, AI Compose
// Visual source of truth — Parker Construction
// ============================================================

const DTopbar2 = window.DTopbar;

// ============================================================
// 05 · MONEY OWED — A/R cockpit
// ============================================================
window.DesktopOwed = function DesktopOwed() {
  const invoices = [
    { i: 'HN', n: 'Heather Neighbor', job: 'Summer Creek deck rebuild', inv: '#2024-061-3', amt: '$12,400', age: 42, sent: 'Mar 12 · 6 nudges', state: 'overdue', alert: true },
    { i: 'BC', n: 'Bishop Construction', job: 'Sub-deck framing — Lot 14', inv: '#2024-058-1', amt: '$6,800', age: 28, sent: 'Mar 26 · 2 nudges', state: 'overdue' },
    { i: 'TJ', n: 'Tom Jameson', job: 'Westwood addition', inv: '#2024-052-2', amt: '$5,100', age: 14, sent: 'Apr 9 · 1 nudge', state: 'pending' },
    { i: 'MM', n: 'MMC Properties', job: 'Summer Creek framing draw 3', inv: '#2024-061-4', amt: '$18,200', age: 6, sent: 'Apr 17 · sent', state: 'pending' },
    { i: 'JR', n: 'Jeff Roy', job: 'Bath remodel · final', inv: '#2024-049-3', amt: '$3,400', age: 3, sent: 'Apr 20 · sent', state: 'pending' },
    { i: 'LG', n: 'Lily Grace', job: 'Mudroom · deposit', inv: '#2024-068-1', amt: '$2,250', age: 0, sent: 'Apr 23 · today', state: 'fresh' },
  ];
  return (
    <div className="desktop-frame">
      <DesktopSidebar active="owed" />
      <div className="dt-main">
        <DTopbar2 crumbs={['PARKER', 'Money owed']} />

        <div className="dt-content">
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 24 }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 8 }}>RECEIVABLES · APRIL 28</div>
              <h1 className="dt-h1" style={{ fontSize: 38 }}>Money <em className="gold-italic">owed.</em></h1>
              <p className="dt-h1__sub">$48,150 across 6 invoices · $19,200 over 30 days</p>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="icon-btn"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg></button>
              <button style={{ padding: '10px 20px', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold))', color: '#1a1208', border: 0, borderRadius: 999, fontWeight: 600, fontSize: 13, cursor: 'pointer', boxShadow: '0 4px 14px rgba(201,150,58,0.32)' }}>+ New invoice</button>
            </div>
          </div>

          {/* Aging strip — visual receivables waterfall */}
          <div className="dt-card" style={{ padding: 24, marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 18 }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 8 }}>AGING · BY BUCKET</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
                  <div className="stamp" style={{ fontSize: 44, color: 'var(--ink)', lineHeight: 1 }}>$48,150</div>
                  <div style={{ fontSize: 12, color: 'var(--ink-3)' }}>total outstanding</div>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="eyebrow" style={{ marginBottom: 8 }}>COLLECTED · APRIL</div>
                <div className="stamp" style={{ fontSize: 26, color: 'var(--good)', lineHeight: 1 }}>$112,400</div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 4 }}>11 invoices · avg 18d</div>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 10 }}>
              {[
                { l: '0–14 DAYS', v: '$23,750', c: 4, color: 'var(--good)', pct: 49 },
                { l: '15–30 DAYS', v: '$5,100', c: 1, color: 'var(--gold-bright)', pct: 11 },
                { l: '31–60 DAYS', v: '$19,200', c: 1, color: '#d97f5b', pct: 40 },
                { l: '60+ DAYS', v: '$0', c: 0, color: 'var(--ink-3)', pct: 0 },
              ].map((b, i) => (
                <div key={i} style={{ padding: 14, background: 'var(--surface-2)', borderRadius: 10, border: '1px solid var(--hair)' }}>
                  <div style={{ height: 4, background: 'var(--surface-1)', borderRadius: 2, marginBottom: 12, overflow: 'hidden' }}>
                    <div style={{ width: `${b.pct}%`, height: '100%', background: b.color }}></div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
                    <div className="eyebrow" style={{ color: b.color, opacity: 0.85 }}>{b.l}</div>
                    <div style={{ fontSize: 10, color: 'var(--ink-3)' }}>{b.c}</div>
                  </div>
                  <div className="stamp" style={{ fontSize: 22, color: 'var(--ink)', marginTop: 8, lineHeight: 1 }}>{b.v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Invoices list + AI follow-up panel */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 16 }}>
            <div className="dt-card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ padding: '14px 20px', display: 'flex', gap: 12, alignItems: 'center', borderBottom: '1px solid var(--hair)' }}>
                <div className="eyebrow" style={{ flex: 1, margin: 0 }}>OPEN INVOICES · 6</div>
                <div style={{ display: 'inline-flex', background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 999, padding: 3 }}>
                  {['All', 'Overdue', 'Pending', 'Sent'].map((t, i) => (
                    <button key={t} style={{ padding: '6px 12px', background: i === 0 ? 'var(--gold-soft)' : 'none', border: 0, borderRadius: 999, color: i === 0 ? 'var(--gold-bright)' : 'var(--ink-2)', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>{t}</button>
                  ))}
                </div>
              </div>
              <div style={{ padding: '8px 20px', borderBottom: '1px solid var(--hair)', display: 'grid', gridTemplateColumns: '38px 1fr 90px 90px 100px 32px', gap: 14, alignItems: 'center' }}>
                <span></span>
                <span className="eyebrow" style={{ margin: 0 }}>CLIENT · JOB</span>
                <span className="eyebrow" style={{ margin: 0, textAlign: 'right' }}>AMOUNT</span>
                <span className="eyebrow" style={{ margin: 0, textAlign: 'center' }}>AGE</span>
                <span className="eyebrow" style={{ margin: 0 }}>LAST TOUCH</span>
                <span></span>
              </div>
              {invoices.map((inv, i) => (
                <div key={i} style={{
                  padding: '14px 20px',
                  display: 'grid', gridTemplateColumns: '38px 1fr 90px 90px 100px 32px', gap: 14,
                  alignItems: 'center',
                  borderBottom: i < invoices.length - 1 ? '1px solid var(--hair)' : '0',
                  background: inv.alert ? 'rgba(217,127,91,0.05)' : 'transparent',
                  cursor: 'pointer',
                }}>
                  <div style={{
                    width: 38, height: 38, borderRadius: '50%',
                    background: inv.alert ? 'rgba(217,127,91,0.12)' : 'var(--surface-2)',
                    border: '1px solid ' + (inv.alert ? 'rgba(217,127,91,0.35)' : 'var(--hair)'),
                    display: 'grid', placeItems: 'center',
                    fontFamily: 'var(--f-stamp)', fontSize: 11,
                    color: inv.alert ? '#d97f5b' : 'var(--ink-2)',
                  }}>{inv.i}</div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', display: 'flex', alignItems: 'center', gap: 8 }}>
                      {inv.n}
                      <span style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--f-stamp)', letterSpacing: '0.04em' }}>{inv.inv}</span>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{inv.job}</div>
                  </div>
                  <div className="stamp" style={{ fontSize: 16, color: inv.alert ? '#d97f5b' : 'var(--ink)', textAlign: 'right' }}>{inv.amt}</div>
                  <div style={{ textAlign: 'center' }}>
                    <span style={{
                      display: 'inline-block', padding: '3px 8px', borderRadius: 4,
                      fontFamily: 'var(--f-stamp)', fontSize: 11, letterSpacing: '0.04em',
                      background: inv.age >= 30 ? 'rgba(217,127,91,0.12)' : inv.age >= 14 ? 'var(--gold-soft)' : 'var(--surface-2)',
                      color: inv.age >= 30 ? '#d97f5b' : inv.age >= 14 ? 'var(--gold-bright)' : 'var(--ink-2)',
                      border: '1px solid ' + (inv.age >= 30 ? 'rgba(217,127,91,0.3)' : inv.age >= 14 ? 'var(--hair-gold)' : 'var(--hair)'),
                    }}>{inv.age === 0 ? 'NEW' : `${inv.age}d`}</span>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{inv.sent}</div>
                  <button className="icon-btn" style={{ width: 28, height: 28 }}>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/></svg>
                  </button>
                </div>
              ))}
            </div>

            {/* AI follow-up panel */}
            <div>
              <div className="dt-card" style={{ padding: 22, marginBottom: 16, borderColor: 'var(--hair-gold)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
                  <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'linear-gradient(135deg, var(--gold-bright), var(--gold-deep))', display: 'grid', placeItems: 'center' }}>
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="#1a1208"><path d="M12 2 14.5 9.5 22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z"/></svg>
                  </div>
                  <div className="eyebrow" style={{ color: 'var(--gold-bright)', margin: 0 }}>AI · NEXT MOVE</div>
                </div>
                <div style={{ fontSize: 17, fontWeight: 600, color: 'var(--ink)', lineHeight: 1.35, letterSpacing: '-0.005em', marginBottom: 6 }}>
                  Send a warm 3-line nudge to <em className="gold-italic">Heather</em>.
                </div>
                <div style={{ fontSize: 12, color: 'var(--ink-3)', lineHeight: 1.55, marginBottom: 16 }}>
                  $12,400 · 42d overdue · 6 prior touches. Past warm-tone replies got paid in 4 days. Try a Thursday site-walk offer.
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button style={{ flex: 1, padding: '10px 14px', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold))', color: '#1a1208', border: 0, borderRadius: 8, fontWeight: 600, fontSize: 12, cursor: 'pointer' }}>Compose with AI</button>
                  <button style={{ padding: '10px 14px', background: 'var(--surface-2)', color: 'var(--ink-2)', border: '1px solid var(--hair)', borderRadius: 8, fontSize: 12, cursor: 'pointer' }}>Skip</button>
                </div>
              </div>

              <div className="dt-card" style={{ padding: 22 }}>
                <div className="eyebrow" style={{ marginBottom: 14 }}>FOLLOW-UP CADENCE</div>
                <div style={{ display: 'grid', gap: 10 }}>
                  {[
                    { d: 'Day 0', l: 'Invoice sent', done: true },
                    { d: 'Day 7', l: 'Friendly reminder', done: true },
                    { d: 'Day 14', l: 'Phone follow-up', done: true },
                    { d: 'Day 30', l: 'Statement + offer', done: true },
                    { d: 'Day 45', l: 'Owner call', current: true },
                    { d: 'Day 60', l: 'Final notice', done: false },
                  ].map((s, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 12px', background: s.current ? 'var(--gold-soft)' : 'transparent', border: '1px solid ' + (s.current ? 'var(--hair-gold)' : 'transparent'), borderRadius: 8 }}>
                      <div style={{
                        width: 18, height: 18, borderRadius: '50%',
                        background: s.done ? 'var(--good)' : s.current ? 'var(--gold-bright)' : 'var(--surface-2)',
                        border: '1px solid ' + (s.done ? 'var(--good)' : s.current ? 'var(--gold-bright)' : 'var(--hair)'),
                        display: 'grid', placeItems: 'center', flexShrink: 0,
                      }}>
                        {s.done && <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#1a1208" strokeWidth="3" strokeLinecap="round"><path d="m5 12 5 5L20 7"/></svg>}
                      </div>
                      <div style={{ fontFamily: 'var(--f-stamp)', fontSize: 11, color: s.done ? 'var(--ink-3)' : s.current ? 'var(--gold-bright)' : 'var(--ink-3)', letterSpacing: '0.04em', minWidth: 50 }}>{s.d}</div>
                      <div style={{ flex: 1, fontSize: 12, color: s.done ? 'var(--ink-3)' : 'var(--ink)', fontWeight: s.current ? 600 : 400 }}>{s.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// 06 · ESTIMATE BUILDER + PREVIEW
// ============================================================
window.DesktopEstimate = function DesktopEstimate() {
  const sections = [
    { n: 'Demo + site prep', items: 3, cost: 4200, locked: true },
    { n: 'Framing — deck + posts', items: 8, cost: 12400, locked: true },
    { n: 'Decking + railings', items: 6, cost: 9800, locked: false, hot: true },
    { n: 'Stairs + landings', items: 4, cost: 3600, locked: false },
    { n: 'Finish + sealant', items: 5, cost: 1800, locked: false },
  ];
  return (
    <div className="desktop-frame">
      <DesktopSidebar active="estimates" />
      <div className="dt-main">
        <DTopbar2 crumbs={['PARKER', 'Estimates', 'Lily Grace · Mudroom + deck']} />

        <div className="dt-content" style={{ paddingBottom: 0 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 24, marginBottom: 22 }}>
            <div style={{ flex: 1 }}>
              <div className="eyebrow" style={{ marginBottom: 8 }}>EST-2024-0072 · DRAFT v3 · saved 6 min ago</div>
              <h1 className="dt-h1" style={{ fontSize: 36 }}>Mudroom build &amp; deck <em className="gold-italic">refresh.</em></h1>
              <p className="dt-h1__sub">Lily Grace · 218 Old Hickory Ln · walkthrough Apr 26 · target start May 6</p>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <button className="icon-btn"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/></svg></button>
              <button style={{ padding: '10px 18px', background: 'var(--surface-2)', color: 'var(--ink)', border: '1px solid var(--hair)', borderRadius: 999, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Preview</button>
              <button style={{ padding: '10px 22px', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold))', color: '#1a1208', border: 0, borderRadius: 999, fontWeight: 600, fontSize: 13, cursor: 'pointer', boxShadow: '0 4px 14px rgba(201,150,58,0.32)' }}>Send to client</button>
            </div>
          </div>

          {/* Two-pane: builder | preview */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.05fr 1fr', gap: 16, height: 720 }}>

            {/* LEFT — builder */}
            <div className="dt-card" style={{ padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
              <div style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--hair)' }}>
                <div className="eyebrow" style={{ margin: 0 }}>SCOPE BUILDER</div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button style={{ padding: '5px 10px', background: 'var(--gold-soft)', color: 'var(--gold-bright)', border: '1px solid var(--hair-gold)', borderRadius: 100, fontSize: 11, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
                    <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 14.5 9.5 22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z"/></svg>
                    AI add section
                  </button>
                  <button style={{ padding: '5px 10px', background: 'var(--surface-2)', color: 'var(--ink-2)', border: '1px solid var(--hair)', borderRadius: 100, fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>Import last job</button>
                </div>
              </div>

              <div style={{ flex: 1, overflowY: 'auto' }}>
                {sections.map((s, i) => (
                  <div key={i} style={{
                    padding: '14px 20px',
                    display: 'flex', alignItems: 'center', gap: 12,
                    borderBottom: i < sections.length - 1 ? '1px solid var(--hair)' : '0',
                    background: s.hot ? 'var(--gold-soft)' : 'transparent',
                    cursor: 'pointer',
                  }}>
                    <div style={{ width: 6, height: 28, background: s.hot ? 'var(--gold-bright)' : s.locked ? 'var(--good)' : 'var(--hair)', borderRadius: 2 }}></div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', display: 'flex', alignItems: 'center', gap: 8 }}>
                        {s.n}
                        {s.hot && <span className="pill pill--gold" style={{ fontSize: 9 }}>EDITING</span>}
                      </div>
                      <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 3 }}>{s.items} line items · {s.locked ? 'priced from history' : 'AI suggesting'}</div>
                    </div>
                    <div className="stamp" style={{ fontSize: 16, color: 'var(--ink)' }}>${s.cost.toLocaleString()}</div>
                    <button className="icon-btn" style={{ width: 28, height: 28 }}>
                      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m6 9 6 6 6-6"/></svg>
                    </button>
                  </div>
                ))}

                {/* Active editor — Decking */}
                <div style={{ padding: '14px 20px 18px', background: 'rgba(207,148,76,0.04)', borderTop: '1px solid var(--hair-gold)' }}>
                  <div className="eyebrow" style={{ color: 'var(--gold-bright)', marginBottom: 12 }}>DECKING + RAILINGS · LINE ITEMS</div>
                  {[
                    { d: 'Ipe decking 5/4×6 — 380 sf', q: '380 sf', u: '$14.50', t: '$5,510' },
                    { d: 'Hidden fastener system', q: '380 sf', u: '$2.20', t: '$836' },
                    { d: 'Aluminum picket railing — 38 lf', q: '38 lf', u: '$78', t: '$2,964' },
                    { d: 'Stainless cable rail — 12 lf', q: '12 lf', u: '$42', t: '$504' },
                    { d: 'Labor — install + finish', q: '24 hr', u: 'crew', t: 'incl' },
                    { d: 'Disposal + cleanup', q: '1', u: '$340', t: '— hide' },
                  ].map((line, i) => (
                    <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 80px 80px 70px', gap: 10, padding: '7px 0', fontSize: 12, color: i === 5 ? 'var(--ink-3)' : 'var(--ink-2)', borderBottom: i < 5 ? '1px solid rgba(207,148,76,0.15)' : '0' }}>
                      <div>{line.d}</div>
                      <div style={{ textAlign: 'right', fontFamily: 'var(--f-stamp)', fontSize: 11, color: 'var(--ink-3)' }}>{line.q}</div>
                      <div style={{ textAlign: 'right', fontFamily: 'var(--f-stamp)', fontSize: 11, color: 'var(--ink-3)' }}>{line.u}</div>
                      <div style={{ textAlign: 'right', fontFamily: 'var(--f-stamp)', fontSize: 12, color: i === 5 ? 'var(--ink-3)' : 'var(--ink)' }}>{line.t}</div>
                    </div>
                  ))}
                  <button style={{ marginTop: 10, padding: '6px 12px', background: 'transparent', color: 'var(--gold-bright)', border: '1px dashed var(--hair-gold)', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer' }}>+ Add line</button>
                </div>
              </div>

              {/* Margin slider — bottom of builder */}
              <div style={{ padding: '14px 20px', borderTop: '1px solid var(--hair)', background: 'var(--surface-1)' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                  <div className="eyebrow" style={{ margin: 0 }}>MARGIN · LIVE</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>Cost: $30,500 · Bid: $46,212</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div className="stamp" style={{ fontSize: 28, color: 'var(--good)', minWidth: 60 }}>34<span style={{ fontSize: 16, opacity: 0.6 }}>%</span></div>
                  <div style={{ flex: 1, position: 'relative', height: 28 }}>
                    <div style={{ position: 'absolute', top: 12, left: 0, right: 0, height: 4, background: 'linear-gradient(90deg, #d97f5b 0%, var(--gold-bright) 50%, var(--good) 100%)', borderRadius: 2 }}></div>
                    <div style={{ position: 'absolute', top: 4, left: '60%', width: 20, height: 20, background: 'var(--ink)', border: '3px solid var(--good)', borderRadius: '50%', transform: 'translateX(-50%)' }}></div>
                    {[15, 25, 35, 45].map((m, i) => (
                      <div key={i} style={{ position: 'absolute', top: 22, left: `${((m - 10) / 40) * 100}%`, transform: 'translateX(-50%)', fontSize: 9, color: 'var(--ink-3)', fontFamily: 'var(--f-stamp)' }}>{m}%</div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT — proposal preview */}
            <div className="dt-card" style={{ padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
              <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--hair)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div className="eyebrow" style={{ margin: 0 }}>CLIENT PREVIEW · WHAT THEY SEE</div>
                <div style={{ display: 'inline-flex', background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 999, padding: 3 }}>
                  {['Web', 'PDF', 'Print'].map((t, i) => (
                    <button key={t} style={{ padding: '4px 10px', background: i === 0 ? 'var(--gold-soft)' : 'none', border: 0, borderRadius: 999, color: i === 0 ? 'var(--gold-bright)' : 'var(--ink-2)', fontSize: 10, fontWeight: 600, cursor: 'pointer' }}>{t}</button>
                  ))}
                </div>
              </div>
              <div style={{ flex: 1, padding: 28, overflowY: 'auto', background: '#0e0c08' }}>
                <div style={{ background: '#fbf6ed', borderRadius: 6, padding: '36px 36px 32px', boxShadow: '0 24px 60px rgba(0,0,0,0.5)', minHeight: '100%' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 26, paddingBottom: 18, borderBottom: '1px solid #d4c5a8' }}>
                    <div>
                      <div style={{ fontFamily: 'var(--f-stamp)', fontSize: 11, letterSpacing: '0.18em', color: '#8b6f3a', marginBottom: 6 }}>PARKER CONSTRUCTION CO.</div>
                      <div style={{ fontSize: 26, fontWeight: 600, color: '#2a1f10', letterSpacing: '-0.01em', fontFamily: 'var(--f-display, serif)' }}>Estimate</div>
                      <div style={{ fontFamily: 'var(--f-stamp)', fontSize: 10, color: '#8b6f3a', marginTop: 4, letterSpacing: '0.06em' }}>EST-2024-0072 · APR 28, 2026</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 11, color: '#7a6448', fontWeight: 600, marginBottom: 3 }}>PREPARED FOR</div>
                      <div style={{ fontSize: 14, color: '#2a1f10', fontWeight: 600 }}>Lily Grace</div>
                      <div style={{ fontSize: 11, color: '#7a6448', marginTop: 2 }}>218 Old Hickory Ln</div>
                    </div>
                  </div>

                  <div style={{ fontSize: 13, color: '#3a2f20', lineHeight: 1.55, marginBottom: 20, fontStyle: 'italic' }}>
                    Lily — thanks for the time on Friday. Below is the scope for the mudroom build and ipe deck refresh, broken out the way we walked it.
                  </div>

                  <div style={{ marginBottom: 18 }}>
                    {sections.map((s, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '11px 0', borderBottom: '1px solid #e7dcc4' }}>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 600, color: '#2a1f10' }}>{s.n}</div>
                          <div style={{ fontSize: 11, color: '#7a6448', marginTop: 2 }}>{s.items} items · materials + labor</div>
                        </div>
                        <div style={{ fontFamily: 'var(--f-stamp)', fontSize: 14, color: '#2a1f10' }}>${s.cost.toLocaleString()}</div>
                      </div>
                    ))}
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 0', borderTop: '2px solid #2a1f10' }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: '#2a1f10', letterSpacing: '0.02em' }}>TOTAL</div>
                    <div style={{ fontFamily: 'var(--f-stamp)', fontSize: 24, color: '#2a1f10', letterSpacing: '0.01em' }}>$31,800</div>
                  </div>

                  <div style={{ marginTop: 24, padding: '14px 16px', background: '#f1e7d2', borderRadius: 4, fontSize: 11, color: '#5a4830', lineHeight: 1.5 }}>
                    <b style={{ color: '#2a1f10' }}>Schedule.</b> 14 working days, target start May 6. Deposit 30% on signature; balance billed in 3 draws.
                  </div>

                  <div style={{ marginTop: 28, paddingTop: 14, borderTop: '1px solid #d4c5a8', display: 'flex', justifyContent: 'space-between', fontSize: 10, color: '#8b6f3a', fontFamily: 'var(--f-stamp)', letterSpacing: '0.06em' }}>
                    <span>JESSE PARKER · OWNER</span>
                    <span>NASHVILLE, TN · LIC #44-3201</span>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// 07 · AI COMPOSE — desktop draft cockpit
// ============================================================
window.DesktopCompose = function DesktopCompose() {
  return (
    <div className="desktop-frame">
      <DesktopSidebar active="messages" />
      <div className="dt-main">
        <DTopbar2 crumbs={['PARKER', 'Messages', 'New · AI compose']} />

        <div className="dt-content" style={{ paddingBottom: 0 }}>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 20 }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 8 }}>AI COMPOSE · FOLLOW-UP · PAYMENT</div>
              <h1 className="dt-h1" style={{ fontSize: 36 }}>To <em className="gold-italic">Heather Neighbor.</em></h1>
              <p className="dt-h1__sub">Summer Creek deck rebuild · invoice #2024-061-3 · 42 days overdue</p>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button style={{ padding: '10px 18px', background: 'var(--surface-2)', color: 'var(--ink)', border: '1px solid var(--hair)', borderRadius: 999, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Save draft</button>
              <button style={{ padding: '10px 22px', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold))', color: '#1a1208', border: 0, borderRadius: 999, fontWeight: 600, fontSize: 13, cursor: 'pointer', boxShadow: '0 4px 14px rgba(201,150,58,0.32)' }}>Send text →</button>
            </div>
          </div>

          {/* Three-column layout: facts | draft hero | adjusters */}
          <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr 300px', gap: 16, height: 720 }}>

            {/* LEFT — facts AI knows */}
            <div className="dt-card" style={{ padding: 22, overflowY: 'auto' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
                <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'linear-gradient(135deg, #3a2a18, #1a1208)', border: '1px solid var(--hair-gold)', display: 'grid', placeItems: 'center', fontFamily: 'var(--f-stamp)', fontSize: 14, color: 'var(--gold-bright)' }}>HN</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>Heather Neighbor</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>(615) 555-0241</div>
                </div>
              </div>

              <div className="eyebrow" style={{ marginBottom: 12, color: 'var(--gold-bright)' }}>4 FACTS USED IN DRAFT</div>
              <div style={{ display: 'grid', gap: 10, marginBottom: 22 }}>
                {[
                  { l: 'INVOICE', v: '#2024-061-3', s: '$12,400 · sent Mar 12' },
                  { l: 'AGE', v: '42 days', s: 'past due Apr 11', alert: true },
                  { l: 'JOB', v: 'Summer Creek deck', s: 'closed out Mar 8 · 100% complete' },
                  { l: 'REFERRAL', v: 'Tom Jameson', s: 'mention as warm signal' },
                ].map((f, i) => (
                  <div key={i} style={{ padding: 12, background: 'var(--surface-2)', border: '1px solid ' + (f.alert ? 'rgba(217,127,91,0.35)' : 'var(--hair)'), borderRadius: 8 }}>
                    <div className="eyebrow" style={{ margin: 0, color: f.alert ? '#d97f5b' : 'var(--ink-3)', fontSize: 9 }}>{f.l}</div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: f.alert ? '#d97f5b' : 'var(--ink)', marginTop: 4 }}>{f.v}</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{f.s}</div>
                  </div>
                ))}
              </div>

              <div className="eyebrow" style={{ marginBottom: 10 }}>HISTORY · LAST 6 TOUCHES</div>
              <div style={{ display: 'grid', gap: 6 }}>
                {[
                  { d: 'Apr 23', t: 'Text · no reply', dim: true },
                  { d: 'Apr 16', t: 'Email · opened 2x', dim: true },
                  { d: 'Apr 9', t: 'Voicemail · no callback', dim: true },
                  { d: 'Mar 28', t: 'Site walkthrough · friendly', dim: false },
                ].map((h, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 10px', background: i === 3 ? 'var(--gold-soft)' : 'transparent', borderRadius: 6 }}>
                    <span style={{ fontFamily: 'var(--f-stamp)', fontSize: 10, color: 'var(--ink-3)', letterSpacing: '0.04em' }}>{h.d.toUpperCase()}</span>
                    <span style={{ fontSize: 11, color: i === 3 ? 'var(--gold-bright)' : 'var(--ink-2)', fontWeight: i === 3 ? 600 : 400 }}>{h.t}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CENTER — draft hero */}
            <div className="dt-card" style={{ padding: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              <div style={{ padding: '14px 24px', borderBottom: '1px solid var(--hair)', display: 'flex', alignItems: 'center', gap: 0 }}>
                {[
                  { id: 'text', l: 'Text', on: true, sub: '1 SMS · 42 words' },
                  { id: 'email', l: 'Email', on: false, sub: '~30 sec read' },
                  { id: 'voice', l: 'Voicemail', on: false, sub: '0:24 · in your voice' },
                ].map((c, i) => (
                  <button key={i} style={{
                    padding: '10px 18px',
                    background: c.on ? 'var(--gold-soft)' : 'transparent',
                    color: c.on ? 'var(--gold-bright)' : 'var(--ink-2)',
                    border: c.on ? '1px solid var(--hair-gold)' : '1px solid transparent',
                    borderRadius: 8, marginRight: 6,
                    fontSize: 12, fontWeight: 600, cursor: 'pointer',
                    textAlign: 'left',
                  }}>
                    <div>{c.l}</div>
                    <div style={{ fontSize: 9, fontFamily: 'var(--f-stamp)', letterSpacing: '0.06em', opacity: 0.7, marginTop: 2 }}>{c.sub}</div>
                  </button>
                ))}
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
                  <button className="icon-btn" style={{ width: 32, height: 32 }} title="Regenerate">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
                  </button>
                </div>
              </div>

              <div style={{ flex: 1, padding: 32, background: '#0a0805', display: 'flex', flexDirection: 'column', alignItems: 'center', overflowY: 'auto' }}>
                {/* Phone mockup of the actual text */}
                <div style={{ width: 360, background: '#0d0d0c', borderRadius: 24, border: '1px solid var(--hair)', padding: '14px 16px 24px', boxShadow: '0 24px 60px rgba(0,0,0,0.6)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontFamily: 'var(--f-stamp)', fontSize: 10, letterSpacing: '0.08em', color: 'var(--ink-2)', marginBottom: 14, padding: '0 4px' }}>
                    <span>9:42</span>
                    <span style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                      <svg width="13" height="9" viewBox="0 0 17 11" fill="currentColor"><path d="M1 8h2v2H1zM5 6h2v4H5zM9 4h2v6H9zM13 1h2v9h-2z"/></svg>
                      <svg width="20" height="9" viewBox="0 0 24 11"><rect x="1" y="1" width="20" height="9" rx="2.5" stroke="currentColor" strokeOpacity="0.6" fill="none"/><rect x="2.5" y="2.5" width="15" height="6" rx="1" fill="currentColor"/></svg>
                    </span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingBottom: 12, borderBottom: '1px solid var(--hair)' }}>
                    <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'linear-gradient(135deg, #3a2a18, #1a1208)', border: '1px solid var(--hair-gold)', display: 'grid', placeItems: 'center', fontFamily: 'var(--f-stamp)', fontSize: 11, color: 'var(--gold-bright)' }}>HN</div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)' }}>Heather Neighbor</div>
                      <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--f-stamp)', letterSpacing: '0.04em', marginTop: 1 }}>+1 (615) 555-0241</div>
                    </div>
                  </div>
                  <div style={{ padding: '20px 4px 4px' }}>
                    <div style={{ textAlign: 'center', fontSize: 10, color: 'var(--ink-3)', letterSpacing: '0.18em', fontFamily: 'var(--f-stamp)', marginBottom: 14 }}>TUE · 9:42 AM</div>
                    <div style={{
                      maxWidth: '88%',
                      padding: '12px 14px',
                      background: 'linear-gradient(180deg, #2c6cf2, #1f54c4)',
                      color: '#fff',
                      borderRadius: '18px 18px 4px 18px',
                      marginLeft: 'auto',
                      fontSize: 13.5, lineHeight: 1.45,
                      whiteSpace: 'pre-wrap',
                      boxShadow: '0 2px 8px rgba(31,84,196,0.35)',
                    }}>
                      Hey Heather, just circling back on invoice <b>#2024-061-3</b> for <b>$12,400</b> on the deck rebuild. I know things get busy.{'\n\n'}Happy to swing by <b>Thursday afternoon</b> to walk any final punch items if that helps. — Jesse
                    </div>
                    <div style={{ textAlign: 'right', marginTop: 6, fontSize: 9, color: 'var(--ink-3)', fontFamily: 'var(--f-stamp)', letterSpacing: '0.04em' }}>DELIVERED · 9:42</div>
                  </div>
                </div>

                {/* Inline reasoning bar */}
                <div style={{ marginTop: 22, maxWidth: 460, padding: '12px 16px', background: 'rgba(207,148,76,0.05)', border: '1px solid var(--hair-gold)', borderLeft: '3px solid var(--gold-bright)', borderRadius: '0 10px 10px 0' }}>
                  <div className="eyebrow" style={{ color: 'var(--gold-bright)', marginBottom: 6, fontSize: 9 }}>WHY THIS DRAFT</div>
                  <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.55 }}>
                    Warm tone matches her replies in March. Thursday-walk offer is your standard close-out gesture — she said yes to it twice last summer.
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT — adjusters */}
            <div className="dt-card" style={{ padding: 22, overflowY: 'auto' }}>
              <div className="eyebrow" style={{ marginBottom: 12 }}>TONE</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 22 }}>
                {['Warm', 'Direct', 'Formal', 'Urgent'].map((t, i) => (
                  <button key={t} style={{
                    padding: '10px 12px',
                    background: i === 0 ? 'var(--gold-soft)' : 'var(--surface-2)',
                    color: i === 0 ? 'var(--gold-bright)' : 'var(--ink-2)',
                    border: '1px solid ' + (i === 0 ? 'var(--hair-gold)' : 'var(--hair)'),
                    borderRadius: 8,
                    fontSize: 12, fontWeight: 600, cursor: 'pointer',
                    textAlign: 'center',
                  }}>{t}</button>
                ))}
              </div>

              <div className="eyebrow" style={{ marginBottom: 12 }}>LENGTH</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6, marginBottom: 22 }}>
                {['Short', 'Just right', 'Detailed'].map((t, i) => (
                  <button key={t} style={{
                    padding: '10px 6px',
                    background: i === 1 ? 'var(--gold-soft)' : 'var(--surface-2)',
                    color: i === 1 ? 'var(--gold-bright)' : 'var(--ink-2)',
                    border: '1px solid ' + (i === 1 ? 'var(--hair-gold)' : 'var(--hair)'),
                    borderRadius: 8,
                    fontSize: 11, fontWeight: 600, cursor: 'pointer',
                  }}>{t}</button>
                ))}
              </div>

              <div className="eyebrow" style={{ marginBottom: 12 }}>EMPHASIZE</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 22 }}>
                {[
                  ['Site walkthrough offer', true],
                  ['Tom referral', false],
                  ['Specific date', true],
                  ['Total amount', true],
                  ['Apologetic tone', false],
                ].map(([t, on], i) => (
                  <button key={i} style={{
                    padding: '6px 10px',
                    background: on ? 'var(--gold-soft)' : 'var(--surface-2)',
                    color: on ? 'var(--gold-bright)' : 'var(--ink-3)',
                    border: '1px solid ' + (on ? 'var(--hair-gold)' : 'var(--hair)'),
                    borderRadius: 100,
                    fontSize: 11, cursor: 'pointer',
                  }}>{on ? '✓ ' : '+ '}{t}</button>
                ))}
              </div>

              <div className="eyebrow" style={{ marginBottom: 10 }}>NOTES TO AI · OPTIONAL</div>
              <div style={{ background: 'var(--surface-2)', border: '1px solid var(--hair)', borderRadius: 8, padding: 12, marginBottom: 22 }}>
                <div style={{ fontSize: 12, color: 'var(--ink-2)', lineHeight: 1.5, fontStyle: 'italic' }}>
                  "Mention I'll be on the road tomorrow but happy to swing by Thursday. Keep it warm — they're a referral from Tom."
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--hair)' }}>
                  <span style={{ fontFamily: 'var(--f-stamp)', fontSize: 10, color: 'var(--ink-3)', letterSpacing: '0.06em' }}>22 WORDS</span>
                  <button style={{ padding: '4px 10px', background: 'var(--gold-soft)', color: 'var(--gold-bright)', border: '1px solid var(--hair-gold)', borderRadius: 100, fontSize: 10, fontWeight: 600, cursor: 'pointer' }}>VOICE</button>
                </div>
              </div>

              <div style={{ paddingTop: 14, borderTop: '1px solid var(--hair)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 11 }}>
                <div>
                  <div className="eyebrow" style={{ margin: 0, marginBottom: 4 }}>SEND BEST</div>
                  <div style={{ color: 'var(--ink)', fontWeight: 600 }}>Tue 9–11 am</div>
                </div>
                <div>
                  <div className="eyebrow" style={{ margin: 0, marginBottom: 4 }}>REPLY ODDS</div>
                  <div style={{ color: 'var(--good)', fontWeight: 600 }}>72%</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
