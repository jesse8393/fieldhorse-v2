/* global React */

const Caret2 = ({ size = 12 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="m9 18 6-6-6-6"/></svg>
);

// ============================================================
// 04 · JOB DETAIL — real (deeper than v1 detail)
// ============================================================
window.JobDetailRealScreen = function JobDetailRealScreen() {
  const [tab, setTab] = React.useState('overview');
  const pct = 0.62;
  return (
    <div className="screen">
      <div className="jd2-head">
        <div className="jd2-head__crumb">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m15 18-6-6 6-6"/></svg>
          JOBS · MMC PROPERTIES
        </div>
        <div className="jd2-head__actions">
          <button className="icon-btn" aria-label="Map">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M1 6v16l7-4 8 4 7-4V2l-7 4-8-4-7 4z"/><path d="M8 2v16M16 6v16"/></svg>
          </button>
          <button className="icon-btn" aria-label="More">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>
          </button>
        </div>
      </div>

      <div className="screen__body no-scroll" style={{ paddingBottom: 100, marginTop: -8 }}>
        <div className="jd2-title">
          <div className="jd2-title__client">MMC PROPERTIES · TOM MENDELSON</div>
          <h1 className="jd2-title__h">Summer Creek rail rebuild</h1>
          <div className="jd2-title__meta">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            412 Summer Creek Dr · Brentwood TN
            <span style={{ color: 'var(--ink-4)' }}>·</span>
            <span>Job #2024-087</span>
          </div>
        </div>

        <div className="jd2-step">
          <div className="jd2-step__rail"></div>
          <div className="jd2-step__rail-fill" style={{ width: 'calc(50% - 0px)' }}></div>
          <div className="jd2-step__node is-done">
            <div className="jd2-step__dot">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="m20 6-11 11-5-5"/></svg>
            </div>
            <div className="jd2-step__lbl">Lead</div>
          </div>
          <div className="jd2-step__node is-done">
            <div className="jd2-step__dot">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="m20 6-11 11-5-5"/></svg>
            </div>
            <div className="jd2-step__lbl">Quote</div>
          </div>
          <div className="jd2-step__node is-current">
            <div className="jd2-step__dot">3</div>
            <div className="jd2-step__lbl">Active</div>
          </div>
          <div className="jd2-step__node">
            <div className="jd2-step__dot">4</div>
            <div className="jd2-step__lbl">Closeout</div>
          </div>
          <div className="jd2-step__node">
            <div className="jd2-step__dot">5</div>
            <div className="jd2-step__lbl">Paid</div>
          </div>
        </div>

        {/* Premium cockpit headline — contract is the hero */}
        <div className="cockpit-headline">
          <div className="cockpit-headline__top">
            <div className="cockpit-headline__l">
              <div className="cockpit-headline__lbl">Contract value</div>
              <div className="cockpit-headline__amt">$46,200</div>
              <div className="cockpit-headline__sub">Signed Apr 11 · Job #2024-087</div>
            </div>
            <div className="cockpit-headline__r">
              <div className="cockpit-headline__lbl">Margin</div>
              <div className="cockpit-headline__margin">34%</div>
              <div className="cockpit-headline__sub">$15,700 profit</div>
            </div>
          </div>
          <div className="cockpit-headline__bar">
            <div className="cockpit-headline__bar-fill" style={{ width: `${pct * 100}%` }}></div>
          </div>
          <div className="cockpit-headline__bar-meta">
            <span><b>$28,650</b> billed</span>
            <span>$17,550 remaining</span>
          </div>
        </div>

        {/* Next action — clear primary call to action */}
        <div className="cockpit-action">
          <div className="cockpit-action__icn">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4z"/></svg>
          </div>
          <div className="cockpit-action__main">
            <div className="cockpit-action__lbl">NEXT ACTION</div>
            <div className="cockpit-action__t">Bill Phase 3 · $11,400</div>
            <div className="cockpit-action__sub">Framing closed out · client expects today</div>
          </div>
          <button className="cockpit-action__cta">Send</button>
        </div>

        {/* Health snapshot — three balanced cells */}
        <div className="cockpit-health">
          <div className="cockpit-health__cell">
            <div className="cockpit-health__lbl">Health</div>
            <div className="cockpit-health__val cockpit-health__val--good">On track</div>
          </div>
          <div className="cockpit-health__cell">
            <div className="cockpit-health__lbl">Phase</div>
            <div className="cockpit-health__val cockpit-health__val--gold">3 of 4</div>
          </div>
          <div className="cockpit-health__cell">
            <div className="cockpit-health__lbl">Days left</div>
            <div className="cockpit-health__val">14</div>
          </div>
        </div>

        <div className="jd2-tabs">
          {[
            ['overview', 'Overview'],
            ['scope', 'Scope'],
            ['money', 'Money'],
            ['files', 'Files'],
          ].map(([k, l]) => (
            <button key={k} className={`jd2-tab ${tab === k ? 'is-on' : ''}`} onClick={() => setTab(k)}>{l}</button>
          ))}
        </div>

        <div className="jd2-progress">
          <div className="jd2-progress__h">
            <span>Phase progress</span>
            <span className="jd2-progress__pct stamp">62%</span>
          </div>
          <div className="jd2-progress__bar">
            <div className="jd2-progress__seg is-on"></div>
            <div className="jd2-progress__seg is-on"></div>
            <div className="jd2-progress__seg is-on" style={{ background: 'linear-gradient(90deg, var(--gold), rgba(228,190,111,0.4))' }}></div>
            <div className="jd2-progress__seg"></div>
          </div>
          <div className="jd2-progress__legend">
            <span className="is-on">Demo</span>
            <span className="is-on">Frame</span>
            <span className="is-on">Finish</span>
            <span>Closeout</span>
          </div>
        </div>

        <div className="jd2-section-lbl">CLIENT</div>
        <div className="jd2-client">
          <div className="cl-avatar cl-avatar--gold" style={{ width: 38, height: 38, fontSize: 14 }}>TM</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="jd2-client__n">Tom Mendelson</div>
            <div className="jd2-client__sub">MMC Properties · Owner · Verified</div>
          </div>
          <div className="jd2-client__icons">
            <button className="icon-btn" aria-label="Call">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
            </button>
            <button className="icon-btn" aria-label="Message">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            </button>
            <button className="icon-btn" aria-label="Email">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></svg>
            </button>
          </div>
        </div>

        <div className="jd2-section-lbl">RECENT ACTIVITY</div>
        <div className="jd2-act">
          <div className="jd2-act__row">
            <div className="jd2-act__icn jd2-act__icn--good">✓</div>
            <div className="jd2-act__main">
              <div className="jd2-act__t">Framing inspection · <b>passed</b></div>
              <div className="jd2-act__m">Inspector Hall · 2:14 PM yesterday</div>
            </div>
            <span className="jd2-act__tag">PASS</span>
          </div>
          <div className="jd2-act__row">
            <div className="jd2-act__icn jd2-act__icn--gold">$</div>
            <div className="jd2-act__main">
              <div className="jd2-act__t">Phase 2 invoice paid · <b>$14,200</b></div>
              <div className="jd2-act__m">Wire · 9:42 AM Apr 24</div>
            </div>
          </div>
          <div className="jd2-act__row">
            <div className="jd2-act__icn">CO</div>
            <div className="jd2-act__main">
              <div className="jd2-act__t">Change order #2 · <b>2 sconces</b></div>
              <div className="jd2-act__m">+$480 · awaiting signature</div>
            </div>
          </div>
          <div className="jd2-act__row">
            <div className="jd2-act__icn">📷</div>
            <div className="jd2-act__main">
              <div className="jd2-act__t">14 photos · framing closeout</div>
              <div className="jd2-act__m">Apr 25 · uploaded by Mike</div>
            </div>
          </div>
        </div>

        <div className="jd2-section-lbl">QUICK ACTIONS</div>
        <div className="jd2-quick">
          <button className="jd2-quick__btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--gold-bright)" strokeWidth="1.6" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6v6H9z"/></svg>
            Add photo
          </button>
          <button className="jd2-quick__btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--gold-bright)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>
            New CO
          </button>
          <button className="jd2-quick__btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--gold-bright)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
            Schedule
          </button>
        </div>

        <div className="bot-spacer"></div>
      </div>

      <BottomNav active="jobs" />
    </div>
  );
};

// ============================================================
// 05 · ESTIMATE AI BUILDER
// ============================================================
window.EstimateAIScreen = function EstimateAIScreen() {
  const [margin, setMargin] = React.useState(34);
  const cost = 30500;
  const total = Math.round(cost / (1 - margin / 100));
  const profit = total - cost;
  return (
    <div className="screen">
      <div className="app-head app-head--titled">
        <div className="app-head__title-block">
          <div className="eyebrow eyebrow--gold">Estimate builder · Draft</div>
          <h1 className="page-h1">Sarah Whitfield</h1>
          <div className="page-sub">Deck rebuild · 412 Linden Ct</div>
        </div>
        <div className="app-head__actions">
          <button className="icon-btn" aria-label="Close">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
      </div>

      <div className="screen__body no-scroll" style={{ paddingBottom: 100 }}>
        <div className="est-hero">
          <div className="est-hero__head">
            <div className="est-hero__lbl">SCOPE · YOUR DESCRIPTION</div>
            <button className="est-hero__voice">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M19 10a7 7 0 0 1-14 0M12 19v3"/></svg>
              VOICE
            </button>
          </div>
          <div className="est-hero__txt">
            "Tear off existing 16×20 deck, dispose. Build new 18×22 cedar over PT joists, hidden fasteners. Add 8×10 cedar pergola with stained beams, four posts on Simpson hardware. New stairs to grade. Match existing rail height."
          </div>
          <div className="est-hero__bar">
            <span>1:42 captured · 87 words</span>
            <button className="est-hero__edit">Edit text →</button>
          </div>
        </div>

        <div className="est-section-lbl">
          AI LINE ITEMS · <span className="est-section-lbl__hint">7 generated · all editable</span>
        </div>

        <div className="est-preview" style={{ marginBottom: 14 }}>
          <div className="est-preview__rows">
            {[
              ['1', 'Demo & dispose', 'Tear off existing 16×20', '$1,800'],
              ['2', 'Footings & posts', '6 new sonotubes · 48"', '$2,400'],
              ['3', 'PT joist framing', '18×22 · 16" OC w/ flashing', '$4,200'],
              ['4', 'Cedar decking', '5/4×6 hidden fastener · ~400 sf', '$8,650'],
              ['5', 'Stairs & rail', 'Match existing height · code', '$2,900'],
              ['6', 'Cedar pergola', '8×10 · 4 posts · stained', '$6,400'],
              ['7', 'Cleanup & punch', '2 days · final walkthrough', '$1,150'],
            ].map(([n, t, s, a]) => (
              <div key={n} className="est-preview__row">
                <div className="est-preview__num-cell stamp">{n}</div>
                <div className="est-preview__main">
                  {t}
                  <div className="est-preview__sub">{s}</div>
                </div>
                <div className="est-preview__amt stamp">{a}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="est-margin">
          <div className="est-margin__h">
            <div>
              <div className="est-margin__lbl">MARGIN TARGET</div>
              <div className="est-margin__hint">Industry: 28-38% · Your YTD: 32%</div>
            </div>
            <div className="est-margin__pct stamp">{margin}<span>%</span></div>
          </div>
          <div className="est-margin__slider">
            <div className="est-margin__track"></div>
            <div className="est-margin__fill" style={{ width: `${((margin - 15) / 35) * 100}%` }}></div>
            <input type="range" min="15" max="50" value={margin} onChange={(e) => setMargin(Number(e.target.value))}/>
            <svg width="20" height="20" viewBox="0 0 20 20" style={{
              position: 'absolute', top: '50%',
              left: `calc(${((margin - 15) / 35) * 100}% - 10px)`,
              transform: 'translateY(-50%)',
              filter: 'drop-shadow(0 4px 10px rgba(201,150,58,0.5))',
              pointerEvents: 'none',
            }}>
              <circle cx="10" cy="10" r="9" fill="url(#estg)"/>
              <defs><linearGradient id="estg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#E8B865"/><stop offset="100%" stopColor="#C9963A"/></linearGradient></defs>
            </svg>
          </div>
          <div className="est-margin__zones">
            <span>15%</span>
            <span style={{ left: '37%' }}>30</span>
            <span>50%</span>
          </div>

          <div className="est-margin__out">
            <div>
              <div className="est-margin__out-lbl">CLIENT TOTAL</div>
              <div className="est-margin__out-amt stamp">${total.toLocaleString()}</div>
            </div>
            <div className="est-margin__out-div"></div>
            <div>
              <div className="est-margin__out-lbl">YOUR PROFIT</div>
              <div className="est-margin__out-amt stamp" style={{ color: 'var(--gold-bright)' }}>${profit.toLocaleString()}</div>
            </div>
          </div>
        </div>

        <button className="est-generate">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3 2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.6 9.1l5.8-.8L12 3z"/></svg>
          Generate proposal
          <Caret2 size={12}/>
        </button>

        <div className="bot-spacer"></div>
      </div>
    </div>
  );
};

// ============================================================
// 06 · OUTSTANDING BALANCE
// ============================================================
window.OwedScreen = function OwedScreen() {
  const [view, setView] = React.useState('client');
  return (
    <div className="screen">
      <div className="app-head app-head--titled">
        <div className="app-head__title-block">
          <div className="eyebrow eyebrow--alert">3 outstanding</div>
          <h1 className="page-h1">Money owed</h1>
        </div>
        <div className="app-head__actions">
          <button className="icon-btn" aria-label="Send all">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/></svg>
          </button>
        </div>
      </div>

      <div className="screen__body no-scroll" style={{ paddingBottom: 100 }}>
        <div className="owed-hero">
          <div className="owed-hero__sweep"></div>
          <div className="owed-hero__amt stamp">$24,300</div>
          <div className="owed-hero__lbl">TOTAL OUTSTANDING</div>

          <div className="owed-hero__aging">
            <div className="owed-aging__bar">
              <div className="owed-aging__seg--current" style={{ width: '49%' }}></div>
              <div style={{ width: '51%', background: '#E08B7A' }}></div>
            </div>
            <div className="owed-aging__cells">
              <div className="owed-aging__cell">
                <div className="owed-aging__amt stamp">$11,900</div>
                <div className="owed-aging__lbl">Current</div>
              </div>
              <div className="owed-aging__cell" style={{ borderLeft: '1px solid var(--hair)', paddingLeft: 12 }}>
                <div className="owed-aging__amt stamp">$0</div>
                <div className="owed-aging__lbl">31–60d</div>
              </div>
              <div className="owed-aging__cell" style={{ borderLeft: '1px solid var(--hair)', paddingLeft: 12 }}>
                <div className="owed-aging__amt stamp" style={{ color: '#E08B7A' }}>$12,400</div>
                <div className="owed-aging__lbl">60d+</div>
              </div>
            </div>
          </div>

          <div className="owed-hero__tip">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m20 6-11 11-5-5"/></svg>
            $14,200 collected this month · pace +18% vs avg
          </div>
        </div>

        <div className="owed-toggle">
          <button className={`owed-toggle__opt ${view === 'client' ? 'is-on' : ''}`} onClick={() => setView('client')}>By client</button>
          <button className={`owed-toggle__opt ${view === 'age' ? 'is-on' : ''}`} onClick={() => setView('age')}>By age</button>
          <button className={`owed-toggle__opt ${view === 'job' ? 'is-on' : ''}`} onClick={() => setView('job')}>By job</button>
        </div>

        <div className="owed-rows">
          <div className="owed-row is-hot">
            <div className="owed-row__head">
              <div className="owed-row__name">
                Heather Neighbor
                <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="3"/></svg>
              </div>
              <div className="owed-row__amt stamp">$12,400</div>
            </div>
            <div className="owed-row__job">Deck rebuild · Job #2024-061</div>
            <div className="owed-row__bar">
              <div className="owed-row__bar-track" style={{ width: '70%', background: '#E08B7A' }}></div>
            </div>
            <div className="owed-row__foot">
              <span>SENT MAR 17 · INV #2024-061-3</span>
              <span className="owed-row__age" style={{ color: '#E08B7A' }}>42d OVERDUE</span>
            </div>
            <div className="owed-row__actions">
              <button className="owed-row__act">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                Call
              </button>
              <button className="owed-row__act">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                Text
              </button>
              <button className="owed-row__act owed-row__act--gold">
                AI Reminder <Caret2 size={10}/>
              </button>
            </div>
          </div>

          <div className="owed-row">
            <div className="owed-row__head">
              <div className="owed-row__name">Matthew Addition</div>
              <div className="owed-row__amt stamp">$8,400</div>
            </div>
            <div className="owed-row__job">Phase 3 framing · Job #2024-087</div>
            <div className="owed-row__bar">
              <div className="owed-row__bar-track" style={{ width: '12%' }}></div>
            </div>
            <div className="owed-row__foot">
              <span>SENT APR 24 · INV #2024-087-2</span>
              <span>4d · ON TIME</span>
            </div>
            <div className="owed-row__actions">
              <button className="owed-row__act">View</button>
              <button className="owed-row__act">Resend</button>
              <button className="owed-row__act owed-row__act--gold">Mark paid</button>
            </div>
          </div>

          <div className="owed-row">
            <div className="owed-row__head">
              <div className="owed-row__name">Lily Grace North</div>
              <div className="owed-row__amt stamp">$3,500</div>
            </div>
            <div className="owed-row__job">Estimate retainer · Job #2024-094</div>
            <div className="owed-row__bar">
              <div className="owed-row__bar-track" style={{ width: '5%' }}></div>
            </div>
            <div className="owed-row__foot">
              <span>SENT APR 27 · INV #2024-094-R</span>
              <span>1d · ON TIME</span>
            </div>
            <div className="owed-row__actions">
              <button className="owed-row__act">View</button>
              <button className="owed-row__act">Resend</button>
              <button className="owed-row__act owed-row__act--gold">Mark paid</button>
            </div>
          </div>
        </div>

        <div className="bot-spacer"></div>
      </div>

      <BottomNav active="more" />
    </div>
  );
};
