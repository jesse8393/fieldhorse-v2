/* global React, DesignCanvas, DCSection, DCArtboard */

const PhoneFrame = ({ children, status }) => (
  <div className="phone">
    {status && <div className={`impl-status impl-status--${status}`}>{status === 'ready' ? 'Ready · Implement' : status === 'polish' ? 'Polish later' : 'Draft'}</div>}
    <div className="phone__island"></div>
    <div className="phone__sbar">
      <span>9:41</span>
      <span style={{ display: 'inline-flex', gap: 6, alignItems: 'center' }}>
        <svg width="17" height="11" viewBox="0 0 17 11" fill="currentColor"><path d="M1 8h2v2H1zM5 6h2v4H5zM9 4h2v6H9zM13 1h2v9h-2z"/></svg>
        <svg width="15" height="11" viewBox="0 0 15 11" fill="none" stroke="currentColor" strokeWidth="1.2"><path d="M.5 4.5a10 10 0 0 1 14 0M3 7a6.5 6.5 0 0 1 9 0M5.5 9.5a3 3 0 0 1 4 0"/><circle cx="7.5" cy="10" r=".9" fill="currentColor"/></svg>
        <svg width="24" height="11" viewBox="0 0 24 11"><rect x="1" y="1" width="20" height="9" rx="2.5" stroke="currentColor" strokeOpacity="0.5" fill="none"/><rect x="2.5" y="2.5" width="15" height="6" rx="1" fill="currentColor"/></svg>
      </span>
    </div>
    {children}
    <div className="phone__home"><div className="phone__home-bar"></div></div>
  </div>
);

const DesktopStage = ({ children, status }) => (
  <div style={{ position: 'relative', width: '100%', height: '100%', background: '#0a0805', overflow: 'hidden' }}>
    {status && <div className={`impl-status impl-status--${status}`}>{status === 'ready' ? 'Ready · Implement' : status === 'polish' ? 'Polish later' : 'Draft'}</div>}
    {children}
  </div>
);

const Stage = ({ children, status }) => (
  <div style={{ position: 'relative', display: 'grid', placeItems: 'center', height: '100%', padding: 20, background: '#0a0805' }}>
    {status && <div className={`impl-status impl-status--${status}`}>{status === 'ready' ? 'Ready · Implement' : status === 'polish' ? 'Polish later' : 'Draft'}</div>}
    {children}
  </div>
);

function App() {
  return (
    <DesignCanvas title="Fieldhorse v3" subtitle="Premium operating system for high-revenue builders · Refined for production handoff">

      <DCSection id="mobile-dash" title="Mobile · Daily brief">
        <DCArtboard id="home-mobile" label="01 · Home" width={460} height={920}>
          <Stage status="ready"><PhoneFrame><HomeScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="jobs-mobile" label="02 · Jobs &amp; pipeline" width={460} height={920}>
          <Stage status="ready"><PhoneFrame><JobsScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="schedule-mobile" label="03 · Schedule" width={460} height={920}>
          <Stage status="polish"><PhoneFrame><ScheduleScreen /></PhoneFrame></Stage>
        </DCArtboard>
      </DCSection>

      <DCSection id="mobile-flows" title="Mobile · Owner workflows">
        <DCArtboard id="jd2-mobile" label="04 · Job detail" width={460} height={920}>
          <Stage status="ready"><PhoneFrame><JobDetailRealScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="estimate-mobile" label="05 · Estimate · Builder + Preview" width={460} height={920}>
          <Stage status="polish"><PhoneFrame><EstimateScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="clients-mobile" label="06 · Clients" width={460} height={920}>
          <Stage status="ready"><PhoneFrame><ClientsScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="owed-mobile" label="07 · Money owed" width={460} height={920}>
          <Stage status="ready"><PhoneFrame><OwedScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="lead-mobile" label="08 · New lead capture" width={460} height={920}>
          <Stage status="polish"><PhoneFrame><NewLeadScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="notes-mobile" label="09 · Notes &amp; capture" width={460} height={920}>
          <Stage status="polish"><PhoneFrame><NotesScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="cmp-mobile" label="10 · AI compose" width={460} height={920}>
          <Stage status="ready"><PhoneFrame><ComposeScreen /></PhoneFrame></Stage>
        </DCArtboard>
        <DCArtboard id="nav-mobile" label="11 · Nav menu" width={460} height={920}>
          <Stage status="ready"><PhoneFrame><NavScreen /></PhoneFrame></Stage>
        </DCArtboard>
      </DCSection>

      <DCSection id="desktop" title="Desktop · Tablet">
        <DCArtboard id="home-desktop" label="01 · Home" width={1480} height={940}>
          <DesktopStage status="ready"><DesktopHome /></DesktopStage>
        </DCArtboard>
        <DCArtboard id="jobs-desktop" label="02 · Jobs &amp; pipeline" width={1480} height={940}>
          <DesktopStage status="ready"><DesktopJobs /></DesktopStage>
        </DCArtboard>
        <DCArtboard id="jd-desktop" label="03 · Job detail cockpit" width={1480} height={940}>
          <DesktopStage status="ready"><DesktopJobDetail /></DesktopStage>
        </DCArtboard>
        <DCArtboard id="clients-desktop" label="04 · Clients" width={1480} height={940}>
          <DesktopStage status="ready"><DesktopClients /></DesktopStage>
        </DCArtboard>
        <DCArtboard id="owed-desktop" label="05 · Money owed" width={1480} height={940}>
          <DesktopStage status="ready"><DesktopOwed /></DesktopStage>
        </DCArtboard>
        <DCArtboard id="estimate-desktop" label="06 · Estimate builder + preview" width={1480} height={940}>
          <DesktopStage status="ready"><DesktopEstimate /></DesktopStage>
        </DCArtboard>
        <DCArtboard id="compose-desktop" label="07 · AI compose" width={1480} height={940}>
          <DesktopStage status="ready"><DesktopCompose /></DesktopStage>
        </DCArtboard>
      </DCSection>

      <DCSection id="system" title="Design system · Foundation, brand, components">
        <DCArtboard id="system-sheet" label="System sheet · v3 final" width={1500} height={2600}>
          <SystemSheet />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
