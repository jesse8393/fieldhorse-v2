/* global React */
const { useState: useState_d } = React;

// ============================================================
// JOB DETAIL — premium owner view of a single job
// ============================================================
window.JobDetailScreen = function JobDetailScreen() {
  return (
    <div className="screen">
      {/* Detail header */}
      <div className="detail-head">
        <button className="detail-head__back">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="m15 18-6-6 6-6"/></svg>
        </button>
        <div className="detail-head__title">
          <div className="detail-head__client">MMC PROPERTIES</div>
          <div className="detail-head__name">Summer Creek roll painting</div>
        </div>
        <button className="icon-btn" aria-label="More">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/></svg>
        </button>
      </div>

      <div className="screen__body no-scroll" style={{ paddingTop: 0 }}>

        {/* Hero photo strip */}
        <div className="detail-photo">
          <svg viewBox="0 0 390 220" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
            <defs>
              <linearGradient id="dh1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#5a4530"/>
                <stop offset="55%" stopColor="#2a1f15"/>
                <stop offset="100%" stopColor="#0a0805"/>
              </linearGradient>
              <linearGradient id="dh1-vig" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#000" stopOpacity="0"/>
                <stop offset="100%" stopColor="#0B0907" stopOpacity="0.95"/>
              </linearGradient>
            </defs>
            <rect width="390" height="220" fill="url(#dh1)"/>
            <polygon points="0,150 390,130 390,220 0,220" fill="#0e0a07" opacity="0.7"/>
            <rect x="80" y="55" width="160" height="120" fill="#1a130c" stroke="#3a2c1a" strokeWidth="0.5"/>
            <rect x="92" y="68" width="24" height="28" fill="#7a5e30" opacity="0.6"/>
            <rect x="120" y="68" width="24" height="28" fill="#5a4520" opacity="0.5"/>
            <rect x="148" y="68" width="24" height="28" fill="#7a5e30" opacity="0.6"/>
            <rect x="176" y="68" width="24" height="28" fill="#5a4520" opacity="0.5"/>
            <rect x="204" y="68" width="24" height="28" fill="#7a5e30" opacity="0.55"/>
            <rect x="92" y="105" width="24" height="32" fill="#3a2c1a"/>
            <rect x="120" y="105" width="24" height="32" fill="#3a2c1a"/>
            <rect x="148" y="105" width="24" height="32" fill="#3a2c1a"/>
            <rect x="176" y="105" width="24" height="32" fill="#3a2c1a"/>
            <rect x="204" y="105" width="24" height="32" fill="#3a2c1a"/>
            <rect x="260" y="80" width="100" height="95" fill="#1f1810" stroke="#3a2c1a" strokeWidth="0.5"/>
            <rect width="390" height="220" fill="url(#dh1-vig)"/>
          </svg>
          <div className="detail-photo__count">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/></svg>
            <span>1 / 4</span>
          </div>
          <div className="detail-photo__dots">
            <span className="is-on"></span><span></span><span></span><span></span>
          </div>
        </div>

        {/* Headline metrics */}
        <section className="detail-headline">
          <div className="detail-headline__top">
            <span className="stage-pill stage-pill--quote">QUOTE</span>
            <span className="detail-headline__addr">Summer Creek Rd · Westwood, TN</span>
          </div>
          <div className="detail-headline__row">
            <div>
              <div className="detail-headline__lbl">Contract value</div>
              <div className="detail-headline__amt stamp">$46,000</div>
            </div>
            <div className="detail-headline__div"></div>
            <div>
              <div className="detail-headline__lbl">Margin · profit</div>
              <div className="detail-headline__sub"><span className="stamp">38%</span> · <b className="stamp">$17.5K</b></div>
            </div>
          </div>
          <div className="stage-bar" style={{ marginTop: 14 }}>
            <div className="stage-bar__seg is-on is-on--quote"></div>
            <div className="stage-bar__seg is-on is-on--quote"></div>
            <div className="stage-bar__seg"></div>
            <div className="stage-bar__seg"></div>
            <div className="stage-bar__seg"></div>
          </div>
          <div className="detail-headline__steps">
            <span className="is-on">Lead</span>
            <span className="is-on">Quote</span>
            <span>Active</span>
            <span>Invoice</span>
            <span>Won</span>
          </div>
        </section>

        {/* Action sticky */}
        <section className="detail-action">
          <div className="detail-action__icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
          </div>
          <div className="detail-action__main">
            <div className="detail-action__lbl">NEXT ACTION · DUE APR 30</div>
            <div className="detail-action__title">Get approval signed</div>
          </div>
          <button className="detail-action__cta">Mark Done</button>
        </section>

        {/* Tabs */}
        <div className="detail-tabs">
          <button className="detail-tab is-on">Overview</button>
          <button className="detail-tab">Estimate</button>
          <button className="detail-tab">Schedule</button>
          <button className="detail-tab">Files</button>
          <button className="detail-tab">Activity</button>
        </div>

        {/* Client card */}
        <section className="block">
          <div className="block__head">
            <div className="eyebrow">Client</div>
            <button className="link link--mute">Profile →</button>
          </div>
          <div className="detail-client">
            <div className="detail-client__avatar">JS</div>
            <div className="detail-client__main">
              <div className="detail-client__name">John Smith <span className="detail-client__role">Owner</span></div>
              <div className="detail-client__sub">MMC Properties · 3 jobs · <b className="stamp">$62K</b> lifetime</div>
            </div>
            <div className="detail-client__actions">
              <button className="icon-btn icon-btn--sm" aria-label="Call">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
              </button>
              <button className="icon-btn icon-btn--sm" aria-label="Text">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
              </button>
              <button className="icon-btn icon-btn--sm" aria-label="Email">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/></svg>
              </button>
            </div>
          </div>
        </section>

        {/* Financial breakdown */}
        <section className="block">
          <div className="block__head">
            <div className="eyebrow">Financials</div>
            <button className="link">Estimate →</button>
          </div>
          <div className="detail-fin">
            <div className="detail-fin__row">
              <span>Subtotal</span>
              <span className="stamp">$42,400</span>
            </div>
            <div className="detail-fin__row">
              <span>Materials &amp; tax</span>
              <span className="stamp">$3,600</span>
            </div>
            <div className="detail-fin__row detail-fin__row--total">
              <span>Contract total</span>
              <span className="stamp">$46,000</span>
            </div>
            <div className="detail-fin__split">
              <div className="detail-fin__split-row">
                <div className="detail-fin__split-bar">
                  <div className="detail-fin__split-bar-fill" style={{ width: '62%', background: 'var(--gold)' }}></div>
                </div>
              </div>
              <div className="detail-fin__legend">
                <div><span className="dot" style={{ background: 'var(--gold)' }}></span> Profit · <b className="stamp">$17.5K</b></div>
                <div><span className="dot" style={{ background: 'var(--ink-3)', opacity: 0.4 }}></span> Cost · <b className="stamp">$28.5K</b></div>
              </div>
            </div>
          </div>
        </section>

        {/* Activity feed */}
        <section className="block">
          <div className="block__head">
            <div className="eyebrow">Recent activity</div>
            <button className="link">View all →</button>
          </div>
          <div className="detail-act">
            <div className="detail-act__row">
              <div className="detail-act__icon" style={{ background: 'var(--gold-soft)', color: 'var(--gold-bright)' }}>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>
              </div>
              <div className="detail-act__main">
                <div className="detail-act__title">Quote sent · <b>Q-0231</b></div>
                <div className="detail-act__meta">Apr 25 · viewed by client 2x</div>
              </div>
              <div className="detail-act__time stamp">3d</div>
            </div>
            <div className="detail-act__row">
              <div className="detail-act__icon" style={{ background: 'var(--good-soft)', color: 'var(--good)' }}>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="9" cy="9" r="2"/><rect x="3" y="3" width="18" height="18" rx="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/></svg>
              </div>
              <div className="detail-act__main">
                <div className="detail-act__title">Site photos uploaded · <b>4</b></div>
                <div className="detail-act__meta">Apr 24 · by Tim K.</div>
              </div>
              <div className="detail-act__time stamp">4d</div>
            </div>
            <div className="detail-act__row">
              <div className="detail-act__icon" style={{ background: 'rgba(107,124,168,0.15)', color: 'var(--lead)' }}>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
              </div>
              <div className="detail-act__main">
                <div className="detail-act__title">Site walkthrough · <b>72 min</b></div>
                <div className="detail-act__meta">Apr 22 · w/ John Smith</div>
              </div>
              <div className="detail-act__time stamp">6d</div>
            </div>
          </div>
        </section>

        <div className="bot-spacer"></div>
      </div>

      <BottomNav active="jobs" />
    </div>
  );
};
